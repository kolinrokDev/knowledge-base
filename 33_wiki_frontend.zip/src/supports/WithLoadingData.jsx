import PagePreloader from "../components/UI/preloaders/PagePreloader.jsx";
import {useDispatch, useSelector} from "react-redux";
import {defaultLoader} from "../features/loaders/defaultLoader.js";
import {stubLoader} from "../features/loaders/stubLoader.js";
import {useEffect} from "react";
import {getApiUrl} from "./apiUtils.js";
import ServerOverloadPage from "../pages/ServerOverloadPage.jsx";

/**
 * Обёртка для компонента с подгрузкой данных
 * @param resource {string} имя ресурса (имя слайса в Store)
 * @param preloader {JSX.Element} анимация при загрузке
 * @param errorView {JSX.Element} компонент, отображаемый при неполадках на сервере
 * @param isStubLoaded {boolean} индикатор загрузки данных из stubLoader-а (по умолчанию загрузка с сервера)
 * @param converter {function} конвертер данных для загрузчика
 * @param loader загрузчик данных (по умолчанию defaultLoader - использовать только для неперсистентных данных, не использующих данные с других страниц, загружаемых тем же лоудером!)
 * @param dataName {string} имя в сторе загружаемой переменной (по умолчанию data)
 * @param children целевой компонент (ничего передавать не надо, это компонент внутри WithLoadingData)
 * @returns {JSX.Element}
 * @constructor
 */
const WithLoadingData = ({
                             resource,
                             preloader = <PagePreloader/>,
                             errorView = <ServerOverloadPage/>,
                             isStubLoaded = false,
                             converter = data => data,
                             loader = defaultLoader,
                             dataName = 'data',
                             children
                         }) => {

    const dispatch = useDispatch();
    const stateResource = useSelector((state) => state[resource]);

    //Ресурс отсутствует в хранилище
    if (!stateResource) {
        throw new Error(`Ресурс "${resource}" не найден в state`);
    }

    const { isLoading, isError, url } = stateResource;
    const data = stateResource[dataName];

    //Загрузка данных
    useEffect(() => {
        //region Dev-версия TODO вырезать перед релизом
        //Проверка необходимости загрузки данных и способа их получения (из api или из json-заглушки)
        if (!isStubLoaded && !data) {
            dispatch(loader([`${getApiUrl()}/api/${url}`, data => converter(data)])); //загрузка с бека
        } else {
            dispatch(stubLoader([resource, data => converter(data)])); //загрузка заглушки из public/data
        }
        //endregion

        //Prod-версия TODO раскомментировать перед релизом
        // dispatch(loader([`/api/${url}`, data => converter(data)]));
    }, []);

    return isError ? errorView : data && !isLoading ? children : preloader;
};

export default WithLoadingData;