import {useDispatch, useSelector} from "react-redux";
import {useEffect} from "react";
import {fetchArticlesList} from "../features/article/articleSlice.js";
import PagePreloader from "../components/UI/preloaders/PagePreloader.jsx";
import ServerOverloadPage from "../pages/ServerOverloadPage.jsx";

/**
 * Загрузка списка статей
 * @param preloader {JSX.Element} анимация при загрузке
 * @param errorView {JSX.Element} компонент, отображаемый при неполадках на сервере
 * @param children целевой компонент (ничего передавать не надо, это компонент внутри WithLoadingData)
 * @returns {JSX.Element}
 * @constructor
 */
const WithLoadingArticleList = ({
                                    preloader = <PagePreloader/>,
                                    errorView = <ServerOverloadPage/>,
                                    children,
                                }) => {
    const dispatch = useDispatch();
    const {articlesList, status, error} = useSelector((state) => state.article);

    //Загрузка данных
    useEffect(() => {
        dispatch(fetchArticlesList());
    }, []);

    return error ? errorView : articlesList.length && status !== 'loading' ? children : preloader;
};

export default WithLoadingArticleList;