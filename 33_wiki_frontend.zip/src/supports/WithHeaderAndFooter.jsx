import HeaderOthers from "../components/HeaderOthers/HeaderOthers.jsx";
import BackwardButton from "../components/UI/BackWardButton/BackwardButton.jsx"
import React from "react";
import BackgroundContainer from "../components/UI/BackgroundContainer/BackgroundContainer.jsx";

/**
 * Обёртка над компонентом страницы
 * @param children контент страницы
 * @param header заголовок (по умолчанию <HeaderOthers/>)
 * @param buttonBack кнопка "Назад" (по умолчанию <ButtonBack/>)
 * @param footer подвал (по умолчанию <Footer/>)
 * @param background задний фон (по умолчанию отсутствует)
 * @returns {JSX.Element}
 * @constructor
 */
const WithHeaderAndFooter = ({children,
                                 header = <HeaderOthers/>,
                                 buttonBack = <BackwardButton />,
                                 background= <BackgroundContainer/>
}) => {
    return (
        <>
            {background}
            {header}
            {buttonBack}
            {children}
        </>
    );
};

export default WithHeaderAndFooter;