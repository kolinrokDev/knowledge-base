import {useDispatch, useSelector} from "react-redux";
import {useEffect} from "react";
import PagePreloader from "../components/UI/preloaders/PagePreloader.jsx";
import ErrorServer from "../components/UI/ErrorServer/ErrorServer.jsx";
import {getApiUrl} from "./apiUtils.js";

/**
 * Инъекция загружаемых данных.
 * Загружает данные из api-ресурса по ключу и внедряет их в целевой компонент
 * @param resource {string} имя ресурса (имя слайса в Store)
 * @param searchKey {string|number} ключ запроса к api (url/:searchKey)
 * @param loader загрузчик данных (createAsyncThunk)
 * @param component {function} целевой компонент
 * @param converter {function} конвертер данных для загрузчика
 * @param getStateDataFunction {function} функция получения данных из хранилища (обязательно передать state в качестве параметра функции)
 * @param preloader {JSX.Element} прелоадер компонента
 * @param errorView {JSX.Element} компонент, отображаемый при неполадках на сервере
 * @param params {[]} дополнительные параметры для получения данных из хранилища
 * @returns {*|JSX.Element}
 * @constructor
 */
const InjectionData = ({
                           resource,
                           searchKey,
                           loader,
                           component,
                           converter = data => data,
                           getStateDataFunction = (resource, key) => state => state[resource].data[key],
                           preloader = <PagePreloader/>,
                           errorView = <ErrorServer/>,
                           params = []
                       }) => {
    const dispatch = useDispatch();
    const {url, isLoading, isError} = useSelector((state) => state[resource]);
    const data = useSelector(getStateDataFunction(resource, searchKey, ...params));

    //Загрузка данных
    useEffect(() => {
        if (!data) {
            dispatch(loader([`${getApiUrl()}/api/${url}/${searchKey}`, converter]));
        }
    }, [searchKey]);

    return isError ? errorView : data && !isLoading ? component(data) : preloader;
};

export default InjectionData;