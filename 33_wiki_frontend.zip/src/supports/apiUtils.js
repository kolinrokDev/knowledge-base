const API_URL = import.meta.env.VITE_WIKI_APP_API__BASE_URL;

/**
 * Функция для получения базового URL API
 * @returns {string} Базовый URL для API
 */
export const getApiUrl = () => {
  if (window.location.hostname === "localhost") {
    return API_URL; // Локальная разработка
  }
  return ""; // Серверная среда
};

/**
 * Функция для корректировки пути изображения
 * Добавляет или удаляет https:// в зависимости от среды
 * @param {string} src - Исходный путь до изображения
 * @returns {string} Корректный URL для изображения
 */
export const getCorrectImageSrc = (src) => {
  if (!src) return "";

  const API_URL = import.meta.env.VITE_WIKI_APP_API__BASE_URL;

  if (window.location.hostname === "localhost") {
    // Локальная разработка: добавляем полный URL
    return src.startsWith("http") ? src : `${API_URL}${src}`;
  }

  // Серверная среда: добавляем https:// только если его нет
  return src.startsWith("http") ? src : `https://${API_URL}${src}`;
};