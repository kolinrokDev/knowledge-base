/**
 * Функция переименования поля объекта
 * @param obj
 * @param oldKeyName
 * @param newKeyName
 */
export const renameObjectKey = (obj, oldKeyName, newKeyName) => {
    obj[newKeyName] = obj[oldKeyName];
    delete obj[oldKeyName];
};