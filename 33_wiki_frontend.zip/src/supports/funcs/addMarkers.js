/**
 * Маркировка текста
 * @param text ну текст жиш!
 * @param rule регулярное выражение для поиска маркируемого текста
 * @param marker маркер текста (текст обрамляется им с двух сторон)
 */
export const addMarkers = (text, rule, marker) => {
    let markedText = text;
    const found = markedText.match(rule);
    found?.forEach(it => markedText = markedText.replaceAll(it, `${marker}${it}${marker}`));
    return markedText;
};