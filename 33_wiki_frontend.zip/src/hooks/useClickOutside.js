import {useEffect} from "react";

/**
 * Отслеживание кликов за пределами указанного элемента
 * @param elementRef {Object} ссылка на элемент
 * @param closeFunc {function} выполняемая функция
 * @param flag {boolean} индикатор
 */
export const useClickOutside = (elementRef, closeFunc, flag = true) => {
    //Добавление хэндлеров
    useEffect(() => {
        //Проверка активации
        if (flag) {
            const timeout = setTimeout(() => {
                /** Обработка клика за пределами рабочей зоны */
                const clickOutside = (e) => {
                    if (flag && e.target !== elementRef.current) {
                        closeFunc();
                        document.removeEventListener("click", clickOutside);
                    }
                };

                //Добавление слушателя после активации
                document.addEventListener("click", clickOutside);

                return () => {
                    document.removeEventListener("click", clickOutside);
                };
            });

            return () => {
                clearTimeout(timeout);
            }
        }
    }, [flag]);
};