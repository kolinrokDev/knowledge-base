import {useEffect} from "react";
import {toggleFocus} from "../features/managementSiteSlice.js";

/**
 * Хук отслеживания нажатия клавиши
 * @param ddQuerySelector поиск элементов выпадающего меню
 * @param inputQuerySelector поиск элемента строки ввода
 * @param successFunc функция, выполняемая при клике за пределами рабочей зоны
 */
export const useCloseDropDownOnClickOutside = (ddQuerySelector, inputQuerySelector, successFunc) => {

    useEffect(() => {
        const click = (e) => {
            let ddElements = document.querySelectorAll(ddQuerySelector);
            ddElements = Array.from(ddElements);
            const inputEl = document.querySelector(inputQuerySelector);
            if (!ddElements.includes(e.target) && e.target !== inputEl) {
                successFunc();
            }
        }

        document.addEventListener("click", click);

        return () => {document.removeEventListener("click", click)};
    }, []);
}