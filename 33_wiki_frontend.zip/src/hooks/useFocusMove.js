import {useEffect, useState} from "react";

/**
 * Хук для перемещения фокуса клавишами
 * @param elementsCount количество найденных подсказок
 */
export const useFocusMove = (elementsCount) => {
    const [activeElementIndex, setActiveElementIndex] = useState(-1);

    //Добавление слушателя
    useEffect(() => {
        /** Перемещение фокуса */
        const focusMove = (e) => {
            if (e.key === 'ArrowDown' && activeElementIndex < elementsCount - 1) {
                setActiveElementIndex(activeElementIndex + 1);
            }

            if (e.key === 'ArrowUp' && activeElementIndex > -1) {
                setActiveElementIndex(activeElementIndex - 1);
            }
        };

        //Добавляем функцию слушателя нажатия клавиш
        window.addEventListener('keydown', focusMove);

        return () => {
            window.removeEventListener('keydown', focusMove);
        };
    }, [elementsCount, activeElementIndex]);

    //Перемещение фокуса
    useEffect(() => {
        if (activeElementIndex !== -1) {
            //Поместить фокус на элемент выпадающего меню
            const activeElement =
                document.querySelector(`div#dropdown_item_${activeElementIndex}`);
            activeElement.focus();
        } else {
            //Вернуть фокус на поле ввода
            const searchBar = document.querySelector('input#search-bar-input');
            searchBar.focus();
            //Поместить курсор в конец строки
            setTimeout(() => { searchBar.selectionStart = searchBar.selectionEnd = 10000; }, 0);
        }
    }, [activeElementIndex]);
};