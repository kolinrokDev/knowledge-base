import {useSelector} from "react-redux";
import classNames from "classnames";

/**
 * Имя класса с переключением тем
 * @param general класс общих свойств
 * @param light класс светлой темы
 * @param dark класс тёмной темы
 * @returns {*}
 */
export const useClassNameThemeSwitcher = (general, light = "", dark = "") => {
    //Тема сайта
    const theme = useSelector(state => state.site.theme);

    //Стили тем
    const themeStyles = {
        darkTheme: classNames(general, dark),
        lightTheme: classNames(general, light)
    };

    return themeStyles[theme];
};