import {useState} from "react";

/**
 * Хук для отслеживания активного элемента
 * @param object
 * @returns {*&{isActive: boolean, setIsActive: (value: (((prevState: boolean) => boolean) | boolean)) => void}}
 */
export const useWatchActiveElement = (object) => {
    const [isActive, setIsActive] = useState(false);
    return {...object, isActive, setIsActive};
};