import {useEffect} from "react";

/**
 * Снятие фокуса с активного элемента при нажатии кнопки Esc
 * @param func {function} функция, выполняемая после снятия фокуса
 */
export const useEscBtn = (func) => {
    useEffect(() => {
        /** Хендлер кнопки Esc */
        const addEscBtnHandler = (e) => {
            if (e.key === 'Escape') {
                document.activeElement.blur();
                func?.();
            }
        }

        window.addEventListener("keydown", addEscBtnHandler);

        return () => window.removeEventListener("keydown", addEscBtnHandler);
    }, []);
};