import {useEffect} from "react";
import axios from "axios";
import {getApiUrl} from "../supports/apiUtils.js";

/**
 * Отслеживание ввода для отправки поискового запроса на сервер
 * @param searchLine {string} поисковая строка
 * @param setResultList {function} функция установки состояния списка результатов поиска
 */
export const useSearchRequest = (searchLine, setResultList) => {
    useEffect(() => {
        if (searchLine.trim() !== "") {
            const timeout = setTimeout(() => {
                axios.get(`${getApiUrl()}/api/articles/search/?search=${searchLine}`)
                    .then(response => setResultList(response.data))
                    .catch(error => console.error(error.data.message));
            }, 500);

            return () => clearTimeout(timeout);
        } else {
            setResultList([]);
        }
    }, [searchLine]);
};