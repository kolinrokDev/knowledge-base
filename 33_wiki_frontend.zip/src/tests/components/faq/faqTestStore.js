import {configureStore} from "@reduxjs/toolkit";
import menagementSiteSlice from "../../../features/managementSiteSlice.js";
import faqSlice from "../../../features/faq/faqSlice.js";

export const faqTestStore = configureStore({
    reducer: {
        faq: faqSlice,
        site: menagementSiteSlice,
    }
});