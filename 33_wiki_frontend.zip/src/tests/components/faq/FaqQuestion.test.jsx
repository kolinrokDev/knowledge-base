import {Provider} from "react-redux";
import {render, screen, fireEvent} from "@testing-library/react";
import '@testing-library/jest-dom';
import FaqQuestion from "../../../components/FAQ/FaqQuestion.jsx";
import {faqTestStore} from "./faqTestStore.js";

const renderedComponent = () => render(
    <Provider store={faqTestStore}>
        <FaqQuestion index={1} question={{title_question: "question", text_answer: "answer"}}/>
    </Provider>
);

describe('FaqQuestion tests', () => {
    test('FaqQuestion render test', () => {
        renderedComponent();
        expect(screen.getByText('question')).toBeInTheDocument();
        expect(screen.getByText('answer')).toBeInTheDocument();
    });

    test('FaqQuestion className test', () => {
        renderedComponent();
        const element = screen.getByText('question').parentElement;
        expect(element.className).toEqual('faq__question_btn faq__question_btn__dark');
    });

    test('FaqQuestion mouse click test', () => {
        renderedComponent();
        const btn = screen.getByText('question').parentElement;
        const checkbox = btn.parentElement.children[1];
        fireEvent.click(btn);
        expect(checkbox.checked).toBe(true);
    });

    test('FaqQuestion close modal after click by close btn test', () => {
        renderedComponent();
        const openBtn = screen.getByText('question').parentElement;
        const checkbox = openBtn.parentElement.children[1];
        fireEvent.click(openBtn);
        const closeBtn = screen.getByText('answer').parentElement.children[0];
        fireEvent.click(closeBtn);
        expect(checkbox.checked).toBe(false);
    });
});

