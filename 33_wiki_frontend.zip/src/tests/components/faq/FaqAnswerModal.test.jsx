import {Provider} from "react-redux";
import {render, screen} from "@testing-library/react";
import '@testing-library/jest-dom';
import FaqAnswerModal from "../../../components/FAQ/FaqAnswerModal.jsx";
import {faqTestStore} from "./faqTestStore.js";

const renderedComponent = () => render(
    <Provider store={faqTestStore}>
        <FaqAnswerModal answer="answer" closeModal={()=>{}}/>
    </Provider>
);

describe('FaqAnswerModal tests', () => {
   test('FaqAnswerModal render test', () => {
       renderedComponent();
       expect(screen.getByText('answer')).toBeInTheDocument();
   })
});