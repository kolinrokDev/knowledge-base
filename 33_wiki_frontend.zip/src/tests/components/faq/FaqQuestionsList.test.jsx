import {Provider} from "react-redux";
import {render, screen} from "@testing-library/react";
import '@testing-library/jest-dom';
import FaqQuestionsList from "../../../components/FAQ/FaqQuestionsList.jsx";
import {faqTestStore} from "./faqTestStore.js";

const questions = [
    {title_question: "question1", text_answer: "answer1"},
    {title_question: "question2", text_answer: "answer2"},
    {title_question: "question3", text_answer: "answer3"},
    {title_question: "question4", text_answer: "answer4"},
];

const renderedComponent = () => render(
    <Provider store={faqTestStore}>
        <FaqQuestionsList questions={questions}/>
    </Provider>
);

describe('FaqQuestionsList tests', () => {
    test('FaqQuestionsList count test', () => {
        renderedComponent();
        expect(screen.getAllByText(/question./i).length).toBe(4);
        expect(screen.getAllByText(/answer./i).length).toBe(4);
    });
});