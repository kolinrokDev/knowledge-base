import {Provider} from "react-redux";
import FaqTitle from "../../../components/FAQ/FaqTitle.jsx";
import {render, screen} from "@testing-library/react";
import '@testing-library/jest-dom';
import {faqTestStore} from "./faqTestStore.js";

const renderedComponent = () => render(
    <Provider store={faqTestStore}>
        <FaqTitle title="test"/>
    </Provider>
);

describe('FaqTitle test', () => {
    test('FaqTitle current text title test', () => {
        renderedComponent();
        expect(screen.getByText('test')).toBeInTheDocument();
    })
});

