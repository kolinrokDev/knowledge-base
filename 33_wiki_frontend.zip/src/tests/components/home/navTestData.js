export const navTestData = [
    {
        id: 2,
        name: "О школе"
    },
    {
        id: 3,
        name: "Project Manager"
    },
    {
        id: 4,
        name: "TL"
    },
    {
        id: 5,
        name: "Design"
    },
    {
        id: 6,
        name: "Frontend"
    },
    {
        id: 7,
        name: "Backend"
    },
    {
        id: 8,
        name: "QA"
    },
    {
        id: 9,
        name: "Android"
    },
    {
        id: 10,
        name: "iOS"
    },
    {
        id: 11,
        name: "DevOps"
    },
    {
        id: 12,
        name: "DS"
    }
];