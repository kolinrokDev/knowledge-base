import {renderTestComponent} from "../renderTestComponent.js";
import {homeStore} from "./homeStore.js";
import TitleHome from "../../../components/UI/TitleHome/TitleHome.jsx";
import {screen} from "@testing-library/react";
import '@testing-library/jest-dom';
import SearchBarMain from "../../../components/UI/SearchBarMain/SearchBarMain.jsx";

describe("Home page tests", () => {
    test('should render title home', () => {
        renderTestComponent(<TitleHome titleTitle='test title' titleInfo='test info'/>, homeStore);
        expect(screen.getByText('test title')).toBeInTheDocument();
        expect(screen.getByText('test info')).toBeInTheDocument();
    });

    test('should render SearchBarMain', () => {
        renderTestComponent(<SearchBarMain/>, homeStore);
        expect(screen.getByPlaceholderText('Поиск')).toBeInTheDocument();
    });
});
