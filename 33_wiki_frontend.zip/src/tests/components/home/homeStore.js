import {configureStore} from "@reduxjs/toolkit";
import managementSiteSlice from "../../../features/managementSiteSlice.js";

export const homeStore = configureStore({
    reducer: {
        site: managementSiteSlice
    }
});