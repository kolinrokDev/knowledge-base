import {configureStore} from "@reduxjs/toolkit";
import hiringAlgorithmSlice from "../../../features/hiringAlgorithm/hiringAlgorithmSlice.js";
import menagementSiteSlice from "../../../features/managementSiteSlice.js";

export const hiringAlgorithmStore = configureStore({
    reducer: {
        hiringAlgorithm: hiringAlgorithmSlice,
        site: menagementSiteSlice,
    }
});