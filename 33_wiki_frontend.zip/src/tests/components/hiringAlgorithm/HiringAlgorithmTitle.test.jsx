import {screen} from "@testing-library/react";
import '@testing-library/jest-dom';
import {renderTestComponent} from "../renderTestComponent.js";
import HiringAlgorithmTitle from "../../../components/HiringAlgorithm/HiringAlgorithmTitle.jsx";
import {hiringAlgorithmStore} from "./hiringAlgorithmStore.js";

describe('HiringAlgorithmTitle test', () => {
    test('HiringAlgorithmTitle current text title test', () => {
        renderTestComponent(<HiringAlgorithmTitle/>, hiringAlgorithmStore);
        expect(screen.getByText('Алгоритм найма')).toBeInTheDocument();
    })
});