import {render} from "@testing-library/react";
import {Provider} from "react-redux";

export const renderTestComponent = (component, store = store) => render(
    <Provider store={store}>
        {component}
    </Provider>
);
