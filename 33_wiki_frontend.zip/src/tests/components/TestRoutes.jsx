import {BrowserRouter as Router, Route, Routes} from "react-router-dom";

/**
 * Роутер для тестов
 * @param routes {array} массив путей
 * @returns {JSX.Element}
 * @constructor
 */
const TestRouter = ({routes}) => {
    return (
        <Router>
            <Routes>
                {routes.map((route, index) => <Route key={index} path={route.path} element={route.element}/>)}
            </Routes>
        </Router>
    )
};

export default TestRouter;