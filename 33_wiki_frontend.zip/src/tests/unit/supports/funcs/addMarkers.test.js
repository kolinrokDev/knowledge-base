import {Marks} from "../../../../static/marks.js";
import {addMarkers} from "../../../../supports/funcs/addMarkers.js";

describe("Тесты хука добавления маркеров", () => {
    test("тест добавления простых маркеров к простому паттерну поиска", () => {
        const text = "_test text_";
        const rules = /(_)/g;
        const marker = '*';

        const result = addMarkers(text, rules, marker);

        expect(result).toEqual("**_**test text**_**")
    });

    test("тест добавления голубых маркеров к кавычкам", () => {
        const text = "{test text}";

        const result = addMarkers(text, Marks.PATTERNS.BLUE, Marks.MARKERS.BLUE);

        expect(result).toEqual("_{_test text_}_");
    });

    test("тест добавления серого маркера к тексту внутри символов: /* */", () => {
        const text = "/*test text*/";

        const result = addMarkers(text, Marks.PATTERNS.GRAY, Marks.MARKERS.GRAY);

        expect(result).toEqual("`/*test text*/`");
    });
});
