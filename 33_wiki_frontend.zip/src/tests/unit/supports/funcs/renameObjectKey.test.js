import {renameObjectKey} from "../../../../supports/funcs/renameObjectKey.js";


test('renameObjectKey tests', () => {
    const obj = {oldValue: ""};

    renameObjectKey(obj, 'oldValue', 'newValue');
    const keyName = Object.keys(obj)[0];

    expect(keyName).toEqual('newValue');
});