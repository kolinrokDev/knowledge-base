import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";
import WithLoadingData from "../supports/WithLoadingData.jsx";
import FaqMain from "../components/FAQ/FaqMain.jsx";
import {faqLoader} from "../features/faq/faqSlice.js";

/**
 * Страница FAQ
 * @returns {JSX.Element}
 * @constructor
 */
const FaqPage = () => {
    return (
        <WithHeaderAndFooter>
            <WithLoadingData resource="faq" loader={faqLoader}>
                <FaqMain/>
            </WithLoadingData>
        </WithHeaderAndFooter>
    );
};

export default FaqPage;