import React from "react";
import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";
import TeamRegistrationComponent from "../components/TeamRegistrationComponent/TeamRegistrationComponent.jsx";
import BackgroundTextPages from "../components/UI/BackgroundTextPages/BackgroundTextPages";

const TeamRegistrationPage = () => {
    return (
        <>
            <BackgroundTextPages />
            <WithHeaderAndFooter>
                <TeamRegistrationComponent />
            </WithHeaderAndFooter>
        </>
    );
};

export default TeamRegistrationPage;