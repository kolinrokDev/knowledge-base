import HomeMain from "../components/Home/HomeMain";
import {homePageLoader} from "../features/managementSiteSlice.js";
import WithLoadingData from "../supports/WithLoadingData.jsx";

/**
 * Главная страница
 * @constructor
 */
function Home() {
    return (
        <WithLoadingData loader={homePageLoader} dataName='homeCategories' resource='site'>
            <HomeMain/>
        </WithLoadingData>
    )
}

export default Home;
