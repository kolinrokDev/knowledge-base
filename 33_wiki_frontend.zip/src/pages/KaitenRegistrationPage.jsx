import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";
import BackgroundTextPages from "../components/UI/BackgroundTextPages/BackgroundTextPages";
import KaitenRegistration from "../components/KaitenRegistration/KaitenRegistration";
import { fetchArticlesList, fetchArticle } from "../features/article/articleSlice";
import PagePreloader from "../components/UI/preloaders/PagePreloader.jsx";
import ServerOverloadPage from "./ServerOverloadPage";

const KaitenRegistrationPage = () => {
  const dispatch = useDispatch();
  const { articlesList, data, status, error } = useSelector((state) => state.article);

  useEffect(() => {
    // Загружаем список статей
    dispatch(fetchArticlesList());
  }, [dispatch]);

  useEffect(() => {
    if (articlesList.length > 0) {
      const kaitenArticle = articlesList.find(
        (article) => article.title === "Регистрация в Kaiten"
      );

      if (kaitenArticle) {
        dispatch(fetchArticle(kaitenArticle.id));
      }
    }
  }, [dispatch, articlesList]);


  return (
    <>
      <BackgroundTextPages />
      <WithHeaderAndFooter>
        {status === "loading" && <PagePreloader />}
        {status === "failed" && <ServerOverloadPage />}
        {data && <KaitenRegistration article={data} />}
      </WithHeaderAndFooter>
    </>
  );
};

export default KaitenRegistrationPage;
