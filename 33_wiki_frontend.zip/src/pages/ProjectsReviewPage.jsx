import TitleHome from "../components/UI/TitleHome/TitleHome";
import ProjectsReview from "../components/ProjectsReview/ProjectsReview.jsx";
import BackgroundContainer from "../components/UI/BackgroundContainer/BackgroundContainer.jsx";
import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";

function ProjectsReviewPage() {

  return (
    <>
      <BackgroundContainer />
      <WithHeaderAndFooter>
          <TitleHome
            titleTitle="Обзор проектов"
            titleInfo="Краткий обзор проектов, среди которых вы можете выбрать один для его реализации"
          />
        <ProjectsReview />
      </WithHeaderAndFooter>
    </>
  );
}

export default ProjectsReviewPage;
