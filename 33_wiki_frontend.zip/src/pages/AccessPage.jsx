import React from "react";
import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";
import AccessComponent from "../components/AccessComponent/AccessComponent";
import BackgroundTextPages from "../components/UI/BackgroundTextPages/BackgroundTextPages";

const AccessPage = () => {
    return (
        <>
            <BackgroundTextPages />
            <WithHeaderAndFooter>
                <AccessComponent />
            </WithHeaderAndFooter>
        </>
    );
};

export default AccessPage;