import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";
import BackgroundTextPages from "../components/UI/BackgroundTextPages/BackgroundTextPages";
import WithLoadingArticleList from "../supports/WithLoadingArticleList.jsx";
import HiringAlgorithmArticleLoad from "../components/HiringAlgorithm/HiringAlgorithmArticleLoad.jsx";

/**
 * Страница алгоритмов найма
 * @returns {JSX.Element}
 * @constructor
 */
const HiringAlgorithmPage = () => {
    return (
        <WithHeaderAndFooter background={<BackgroundTextPages/>}>
            <WithLoadingArticleList>
                <HiringAlgorithmArticleLoad/>
            </WithLoadingArticleList>
        </WithHeaderAndFooter>
    );
};

export default HiringAlgorithmPage;