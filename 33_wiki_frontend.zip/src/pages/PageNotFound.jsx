import ErrorPageBanner from "../components/UI/ErrorPageBanner/ErrorPageBanner.jsx";
import BackgroundContainer from "../components/UI/BackgroundContainer/BackgroundContainer";
import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";

function PageNotFound() {
  return (
    <>
    <WithHeaderAndFooter>
      <BackgroundContainer />
      <ErrorPageBanner />
    </WithHeaderAndFooter>
    </>
  );
}

export default PageNotFound;
