import ErrorServer from "../components/UI/ErrorServer/ErrorServer";
import WithHeaderAndFooter from "../supports/WithHeaderAndFooter";

const ServerOverloadPage = () => {
    return (
        <>
            <WithHeaderAndFooter>
                <ErrorServer />
            </WithHeaderAndFooter>
        </>
    )
}

export default ServerOverloadPage;
