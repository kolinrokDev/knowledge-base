import {useParams} from "react-router-dom";
import PageTemplateMain from "../components/PageTemplate/PageTemplateMain.jsx";
import {categoryLoader} from "../features/managementSiteSlice.js";
import InjectionData from "../supports/InjectionData.jsx";

const PageTemplate = () => {
    const {id} = useParams();

    return <InjectionData resource="site" searchKey={id} loader={categoryLoader}
                       component={data => <PageTemplateMain category={data}/>}/>;
};

export default PageTemplate;
