import React, { useEffect } from "react";
import BackgroundTextPages from "../components/UI/BackgroundTextPages/BackgroundTextPages";
import { useDispatch, useSelector } from "react-redux";
import { fetchArticlesList, fetchArticle, resetArticle } from "../features/article/articleSlice";
import Interview from "../components/Interview/Interview";
import PagePreloader from "../components/UI/preloaders/PagePreloader";
import WithHeaderAndFooter from "../supports/WithHeaderAndFooter";

const InterviewPage = () => {
  const { theme } = useSelector((state) => state.site);
  const dispatch = useDispatch();
  const {
    articlesList,
    data: article,
    status,
    error,
  } = useSelector((state) => state.article);

  useEffect(() => {
    // Загрузка списка статей
    dispatch(fetchArticlesList()).then((action) => {
      if (action.payload) {
        const targetArticle = action.payload.find((item) => item.title === "Интервью с кандидатом");
        if (targetArticle) {
          dispatch(fetchArticle(targetArticle.id));
        }
      }
    });

    return () => {
      dispatch(resetArticle());
    };
  }, [dispatch]);

  return (
    <>
      <BackgroundTextPages />
      <WithHeaderAndFooter>
        {status !== "loading" && article ? (
          <Interview article={article} theme={theme} />
        ) : (
          <PagePreloader />
        )}
        {status === "failed" ? <ServerOverloadPage /> : ""}
      </WithHeaderAndFooter>
    </>
  );
};

export default InterviewPage;

