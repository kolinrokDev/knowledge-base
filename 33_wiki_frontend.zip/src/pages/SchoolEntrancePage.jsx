import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";
import SchoolEntrance from "../components/SchoolEntrance/SchoolEntrance";
import BackgroundTextPages from "../components/UI/BackgroundTextPages/BackgroundTextPages";
import { fetchArticlesList, fetchArticle } from "../features/article/articleSlice";
import PagePreloader from "../components/UI/preloaders/PagePreloader.jsx";
import ServerOverloadPage from "./ServerOverloadPage";

const SchoolEntrancePage = () => {
  const dispatch = useDispatch();
    const { articlesList, data, status, error } = useSelector((state) => state.article);
  
    useEffect(() => {
      // Загружаем список статей
      dispatch(fetchArticlesList());
    }, [dispatch]);
  
    useEffect(() => {
      if (articlesList.length > 0) {
        const schoolEnterenceArticle = articlesList.find(
          (article) => article.title === "Вход в GoD"
        );
  
        if (schoolEnterenceArticle) {
          dispatch(fetchArticle(schoolEnterenceArticle.id));
        }
      }
    }, [dispatch, articlesList]);
  return (
    <>
      <BackgroundTextPages />
      <WithHeaderAndFooter>
        {status === "loading" && <PagePreloader />}
        {status === "failed" && <ServerOverloadPage />}
        {data && <SchoolEntrance article={data} />}
      </WithHeaderAndFooter>
    </>
  );
}

export default SchoolEntrancePage;
