import WithHeaderAndFooter from "../supports/WithHeaderAndFooter.jsx";
import DictionaryMain from "../components/Dictionary/DictionaryMain.jsx";

function DictionaryPage() {
    return (
        <WithHeaderAndFooter>
            <DictionaryMain/>
        </WithHeaderAndFooter>
    );
}

export default DictionaryPage;