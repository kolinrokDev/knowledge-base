import * as Yup from "yup";

export const feedbackValidationSchema = Yup.object().shape({
  username: Yup.string()
    .strict()
    .min(2, "Минимум 2 символа")
    .max(50, "Максимум 50 символов")
    .matches(
      /(^[A-Z]{1}[a-z-]+$)|(^[А-Я]{1}[а-я-]+$)/,
      "Допускается использование только кириллицы или латиницы, а также тире"
    )
    .matches(
      /(^[A-Z]{1}([-]?[a-z]+)*)$|(^[А-Я]{1}([-]?[а-я]+)*$)/,
      "Допускается использование тире, но не более 2 подряд, не в начале и конце"
    )
    .required("Обязательное поле"),
  project_name: Yup.string()
    .min(2, "Минимум 2 символа")
    .max(64, "Максимум 64 символов")
    .required("Обязательное поле"),
  user_role: Yup.string().required("Обязательное поле"),
  element_nickname: Yup.string()
    .strict()
    .min(2, "Минимум 2 символа")
    .max(50, "Максимум 50 символов")
    .test(
      "is-valid-nickname",
      "Никнейм не должен оканчиваться на - или _ и должен содержать доменную часть :guild-of-developers.ru",
      (value) => {
        // Проверяем наличие значения
        if (!value) return false;

        // Проверяем формат ника
        const regex = /^@[A-Za-z0-9]+([-_]?[A-Za-z0-9]+)*:guild-of-developers.ru$/;
        return regex.test(value);
      }
    )
    .required("Обязательное поле"),
  question: Yup.string()
    .strict()
    .min(20, "Минимум 20 символов")
    .matches(
      /^(?! )[\w\W]+(\s?\w+)*$/i,
      "Допускается использование только одного пробела между словами"
    )
    .required("Обязательное поле"),
});