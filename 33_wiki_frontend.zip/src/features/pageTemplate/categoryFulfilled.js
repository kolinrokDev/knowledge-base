import {snakeCaseToCamelCaseConverter} from "../converters/snakeCaseToCamelCaseConverter.js";
import {renameObjectKey} from "../../supports/funcs/renameObjectKey.js";
import {colorThemeConverter} from "../converters/colorThemeConverter.js";

/**
 * Функция сохранения данных подкатегорий в хранилище
 * @param state
 * @param payload
 */
export const categoryFulfilled = (state, {payload}) => {
    payload = snakeCaseToCamelCaseConverter(payload);
    payload.subcategory = payload.subcategory.sort((a, b) => a.id - b.id);
    renameObjectKey(payload, 'categoryName', 'name');
    state.data[payload.id] = colorThemeConverter(payload);
};