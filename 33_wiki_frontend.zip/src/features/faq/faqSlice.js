import PersistSliceManager from "../persistor/persistSliceManager.js";
import CaseCreator from "../cases/caseCreator.js";
import {sortByIdConverter} from "../converters/sortByIdConverter.js";
import {getNewLoader} from "../loaders/getNewLoader.js";

export const faqLoader = getNewLoader();

/**
 * FAQ слайсер
 * @type {CustomSlice}
 */
const faqSlice = PersistSliceManager.create()
    .setName("faq")
    .setUrl("faq/list")
    .addState('title','faq')
    .setLoader(faqLoader)
    .addCases(CaseCreator.create()
        .setLoader(faqLoader)
        .setConverter(sortByIdConverter)
        .build())
    .setDefaultTemporary() // Установить временное хранение с настройками по умолчанию
    .addToBlackList('title') //Данные, которые не нужно сохранять в localstorage
    .build();

export default faqSlice.reducer;