import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { getApiUrl } from "../../supports/apiUtils";

export const fetchFeedback = createAsyncThunk(
    "feedback/fetchFeedback",
    async ({ username, user_role, project_name, element_nickname, question }, { rejectWithValue }) => {
        try {
            const requestData = {
                username,
                user_role,
                project_name,
                element_nickname,
                question,
            };

            const baseUrl = getApiUrl();
            const response = await axios.post(`${baseUrl}/api/feedback/create/`, requestData, {
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                },
                withCredentials: true, // Включаем куки для передачи CSRF-токена
            });

            return response.data;
        } catch (error) {
            console.error(error);

            if (error.response) {
                const status = error.response.status;
                if (status === 503) {
                    return rejectWithValue("Сервис временно недоступен (503)");
                }
                return rejectWithValue(
                    error.response.data?.message || "Произошла ошибка на сервере"
                );
            }
            return rejectWithValue("Не удалось отправить форму обратной связи");
        }
    }
);

const feedbackSlice = createSlice({
    name: "feedback",
    initialState: {
        feedback: null, // Хранение данных отправленной формы
        status: "idle", // idle | loading | succeeded | failed
        error: null, // Сообщение об ошибке
    },
    reducers: {
        // Очистка состояния
        clearFeedback: (state) => {
            state.feedback = null;
            state.status = "idle";
            state.error = null;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchFeedback.pending, (state) => {
                state.status = "loading";
                state.error = null; // Сброс ошибок при новой попытке
            })
            .addCase(fetchFeedback.fulfilled, (state, action) => {
                state.status = "succeeded";
                state.feedback = action.payload; // Сохранение данных из ответа
            })
            .addCase(fetchFeedback.rejected, (state, action) => {
                state.status = "failed";
                state.error = action.payload; // Сохранение сообщения об ошибке
            });
    },
});

export const { clearFeedback } = feedbackSlice.actions;
export default feedbackSlice.reducer;
