/**
 * Преобразователь темы
 * [!] Использовать после преобразователя в верблюжий регистр
 * @param data
 */
export const colorThemeConverter = (data) => {
    switch (data.pageStyle) {
        case '984C00000000':
            data.pageStyle = 'orange';
            break;
        case '116F38/000000':
            data.pageStyle = 'green';
            break;
        case '575297/000000':
            data.pageStyle = 'violet';
            break;
        default:
            data.pageStyle = 'blue';
    }

    return data;
};