import { addMarkers } from "../../supports/funcs/addMarkers.js";
import { Marks } from "../../static/marks.js";

/**
 * Конвертер данных для страницы Алгоритм найма
 * @param data массив данных
 * @returns {*}
 */
export const addBlueMarkersToArticleConverter = (data) => {
    return data.map(article => {
        // Создаем копию объекта, чтобы избежать ошибок с read-only
        const updatedArticle = { ...article };
        updatedArticle.body = addMarkers(updatedArticle.body, Marks.PATTERNS.BLUE, Marks.MARKERS.BLUE);
        updatedArticle.body = addMarkers(updatedArticle.body, Marks.PATTERNS.GRAY, Marks.MARKERS.GRAY);
        return updatedArticle;
    });
};