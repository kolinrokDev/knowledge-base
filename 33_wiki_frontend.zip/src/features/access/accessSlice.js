import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { getApiUrl } from "../../supports/apiUtils";

const baseUrl = getApiUrl();

// Асинхронный thunk для получения списка таблиц
export const fetchTables = createAsyncThunk("access/fetchTables", async (_, thunkAPI) => {
  try {
    const response = await axios.get(`${baseUrl}/api/table/list/`);
    return response.data;
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data || "Ошибка получения списка таблиц");
  }
});

// Асинхронный thunk для получения деталей таблицы
export const fetchTableDetails = createAsyncThunk("access/fetchTableDetails", async (tableId, thunkAPI) => {
    try {
        if (!tableId) {
            throw new Error("ID таблицы отсутствует");
        }
        const response = await axios.get(`${baseUrl}/api/table/detail/${tableId}/`);
        return response.data;
    } catch (error) {
        return thunkAPI.rejectWithValue(error.response?.data || "Ошибка получения деталей таблицы");
    }
});

const accessSlice = createSlice({
  name: "access",
  initialState: {
    tables: [],
    tableDetails: null,
    status: "idle",
    error: null,
  },
  reducers: {
    resetTableDetails(state) {
      state.tableDetails = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Обработка fetchTables
      .addCase(fetchTables.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchTables.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.tables = action.payload;
      })
      .addCase(fetchTables.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      // Обработка fetchTableDetails
      .addCase(fetchTableDetails.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchTableDetails.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.tableDetails = action.payload;
      })
      .addCase(fetchTableDetails.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export const { resetTableDetails } = accessSlice.actions;

export default accessSlice.reducer;
