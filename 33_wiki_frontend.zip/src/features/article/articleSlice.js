import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { getApiUrl } from "../../supports/apiUtils";

const baseUrl = getApiUrl();

// Асинхронный thunk для получения статьи
export const fetchArticle = createAsyncThunk(
  "article/fetchArticle",
  async (id, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${baseUrl}/api/articles/detail/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Асинхронный thunk для получения списка статей
export const fetchArticlesList = createAsyncThunk(
  "article/fetchArticlesList",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${baseUrl}/api/articles/list/`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const articleSlice = createSlice({
  name: "article",
  initialState: {
    data: null,
    articlesList: [],
    status: "idle",
    error: null,
  },
  reducers: {
    resetArticle(state) {
      state.data = null;
      state.status = "idle";
      state.error = null;
    },
    resetArticlesList(state) {
      state.articlesList = [];
      state.status = "idle";
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // fetchArticle
      .addCase(fetchArticle.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchArticle.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.data = action.payload;
      })
      .addCase(fetchArticle.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      // fetchArticlesList
      .addCase(fetchArticlesList.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchArticlesList.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.articlesList = action.payload;
      })
      .addCase(fetchArticlesList.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export const { resetArticle, resetArticlesList } = articleSlice.actions;

export default articleSlice.reducer;
