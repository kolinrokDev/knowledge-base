import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { getApiUrl } from "../../supports/apiUtils";

const baseUrl = getApiUrl();

// Асинхронный thunk для получения списка таблиц
export const fetchPetProjects = createAsyncThunk("petProjects/fetchPetProjects", async (_, thunkAPI) => {
  try {
    const response = await axios.get(`${baseUrl}/api/pet_project/projects/`);
    return response.data;
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data || "Ошибка получения списка проекта");
  }
});

// Асинхронный thunk для получения деталей таблицы
export const fetchPetProjectsDetails = createAsyncThunk("petProjects/fetchPetProjectsDetails", async (id, thunkAPI) => {
    try {
        if (!id) {
            throw new Error("ID проекта отсутствует");
        }
        const response = await axios.get(`${baseUrl}/api/pet_project/projects/${id}/`);
        return response.data;
    } catch (error) {
        return thunkAPI.rejectWithValue(error.response?.data || "Ошибка получения деталей проекта");
    }
});

const petProjectsSlice = createSlice({
  name: "petProjects",
  initialState: {
    petProjects: [],
    petProjectsDetails: null,
    status: "idle",
    error: null,
  },
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      // Обработка fetchPetProjects
      .addCase(fetchPetProjects.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchPetProjects.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.petProjects = action.payload;
      })
      .addCase(fetchPetProjects.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      // Обработка fetchPetProjectsDetails
      .addCase(fetchPetProjectsDetails.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchPetProjectsDetails.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.petProjectsDetails = action.payload;
      })
      .addCase(fetchPetProjectsDetails.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export default petProjectsSlice.reducer;