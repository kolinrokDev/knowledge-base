import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { getApiUrl } from "../../supports/apiUtils";

const baseUrl = getApiUrl();

// Асинхронный thunk для получения всего словаря
export const fetchDictionary = createAsyncThunk(
    "dictionary/fetchDictionary",
    async (_, { rejectWithValue }) => {
      try {
        const response = await axios.get(`${baseUrl}/api/dictionary/words/`);
        return response.data;
      } catch (error) {
        return rejectWithValue(error.response.data);
      }
    }
  );
  
  const dictionarySlice = createSlice({
    name: "dictionary",
    initialState: {
      data: null,
      dictionary: [],
      status: "idle",
      error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
      builder
        // fetchDictionary
        .addCase(fetchDictionary.pending, (state) => {
          state.status = "loading";
          state.error = null;
        })
        .addCase(fetchDictionary.fulfilled, (state, action) => {
          state.status = "succeeded";
          state.dictionary = action.payload;
        })
        .addCase(fetchDictionary.rejected, (state, action) => {
          state.status = "failed";
          state.error = action.payload;
        });
    },
  });
  

export default dictionarySlice.reducer;
