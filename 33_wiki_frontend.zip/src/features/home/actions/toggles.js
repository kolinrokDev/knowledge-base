/**
 * Экшен переключения темы сайта
 * @param state
 * @param action
 */
export const toggleThemeAction = (state, action) => {
    state.theme = action.payload === "darkTheme" ? "lightTheme" : "darkTheme";
};

/**
 * Экшен переключения индикатора фокусировки
 * @param state
 * @param action
 */
export const toggleFocusAction = (state, action) => {
    state.focus = action.payload;
    // action.payload === true ? (state.focus = true) : (state.focus = false);
};

export const toggleModalOverlayAction = (state, action) => {
    state.isModalOverlayOpen = action.payload;
};

//TODO можно убрать, так как есть глобальный общий overlay
export const toggleModalWindowFeedback = (state, action) => {
    state.ModalWindowFeedback = action.payload;
}