import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { getApiUrl } from "../../supports/apiUtils";

export const fetchTeamRegistrationData = createAsyncThunk(
    "teamRegistration/fetchData",
    async (_, { rejectWithValue }) => {
        try {
            const baseUrl = getApiUrl();
            const response = await axios.get(`${baseUrl}/api/table/list/`);
            return response.data;
        } catch (error) {
            console.error("Ошибка запроса:", error.message);

            if (error.response) {
                return rejectWithValue(error.response.data || "Ошибка загрузки данных");
            } else if (error.request) {
                return rejectWithValue("Сервер не ответил на запрос");
            } else {
                return rejectWithValue("Произошла неизвестная ошибка");
            }
        }
    }
);

const teamRegistrationSlice = createSlice({
    name: "teamRegistration",
    initialState: {
        data: [], 
        status: "idle",
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchTeamRegistrationData.pending, (state) => {
                state.status = "loading";
                state.error = null;
            })
            .addCase(fetchTeamRegistrationData.fulfilled, (state, action) => {
                state.status = "succeeded";
                state.data = action.payload;
            })
            .addCase(fetchTeamRegistrationData.rejected, (state, action) => {
                state.status = "failed";
                state.error = action.payload;
            });
    },
});

export default teamRegistrationSlice.reducer;