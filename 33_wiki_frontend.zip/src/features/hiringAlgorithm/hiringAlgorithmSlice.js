import CaseCreator from "../cases/caseCreator.js";
import ConverterChain from "../converters/converterChain.js";
import {addBlueMarkersToArticleConverter} from "../converters/addBlueMarkersToArticleConverter.js";
import {getNewLoader} from "../loaders/getNewLoader.js";
import {snakeCaseToCamelCaseConverter} from "../converters/snakeCaseToCamelCaseConverter.js";
import PersistSliceManager from "../persistor/persistSliceManager.js";

export const hiringAlgorithmLoader = getNewLoader();

/**
 * Slice страницы Алгоритм найма
 * @type {CustomSlice}
 */
const hiringAlgorithmSlice = PersistSliceManager.create()
    .setName("hiringAlgorithm")
    .setUrl(`articles/detail`)
    .addCases(CaseCreator.create(hiringAlgorithmLoader, ConverterChain.create()
        .addConverter(snakeCaseToCamelCaseConverter)
        .addConverter(data => {
            data.articleList = addBlueMarkersToArticleConverter(data.articleText);
            delete data.articleText;
            return data;
        })
        .build()).build())
    .setPersistKey('hiring-algorithm')
    .setDefaultTemporary()
    .build();

export default hiringAlgorithmSlice.reducer;