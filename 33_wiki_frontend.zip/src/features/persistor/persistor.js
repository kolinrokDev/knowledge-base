import {store} from "../../store/store.js";
import {persistStore} from "redux-persist";


export const persistor = persistStore(store);

