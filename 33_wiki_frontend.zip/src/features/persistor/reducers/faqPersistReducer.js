import {persistReducer} from "redux-persist";
import faqSlice from "../../faq/faqSlice.js";
import storage from "redux-persist/lib/storage";

/** Конфигурация хранилища */
const persistConfig = {
    key: 'faq', //ключ в хранилище
    storage, //вид хранилища данных (localstorage)
    blacklist: [ //данные, которые не нужно сохранять в хранилище
        'url',
        'title',
        'isLoading',
        'isError',
    ],
};

/** Персистентное хранилище faq-ов */
export const faqPersistReducer = persistReducer(persistConfig, faqSlice);