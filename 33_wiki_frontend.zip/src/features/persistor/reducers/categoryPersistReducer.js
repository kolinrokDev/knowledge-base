import storage from "redux-persist/lib/storage";
import {persistReducer} from "redux-persist";
import managementSiteSlice from "../../managementSiteSlice.js";
import {getTtlPersistTransform} from "../getTtlPersistTransform.js";

// Время хранения (в миллисекундах)
const TTL = 10;

/** Трансформатор данных */
const categoryTransform = getTtlPersistTransform(TTL, ['theme', 'focus']);

/** Конфигурация хранилища */
const persistConfig = {
    key: 'category', //ключ в хранилище
    storage, //вид хранилища данных (localstorage)
    blacklist: [ //данные, которые не нужно сохранять в хранилище
        'url',
        'homeTitle',
        'homeDescription',
        'isLoading',
        'isError',
        'isModalOverlayOpen',
    ],
    transforms: [categoryTransform],
};

/** Персистентное хранилище категорий */
export const categoryPersistReducer =
    persistReducer(persistConfig, managementSiteSlice);