import {persistReducer} from "redux-persist";
import storage from "redux-persist/lib/storage";
import hiringAlgorithmSlice from "../../hiringAlgorithm/hiringAlgorithmSlice.js";

/** Конфигурация хранилища */
const persistConfig = {
    key: 'hiring-algorithm', //ключ в хранилище
    storage, //вид хранилища данных (localstorage)
    blacklist: [ //данные, которые не нужно сохранять в хранилище
        'url',
        'isLoading',
        'isError',
    ],
};

/** Персистентное хранилище статей алгоритмов найма */
export const hiringAlgorithmReducer = persistReducer(persistConfig, hiringAlgorithmSlice);