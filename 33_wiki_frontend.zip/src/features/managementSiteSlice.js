import { getNewLoader } from "./loaders/getNewLoader.js";
import CaseCreator from "./cases/caseCreator.js";
import { toggleThemeAction, toggleFocusAction, toggleModalOverlayAction } from "./home/actions/toggles.js";
import { categoryFulfilled } from "./pageTemplate/categoryFulfilled.js";
import PersistSliceManager from "./persistor/persistSliceManager.js";

/** Загрузчик данных для категорий */
export const categoryLoader = getNewLoader();

/** Загрузчик данных для главной страницы */
export const homePageLoader = getNewLoader();

/** Данные инициализации хранилища */
const initialState = {
    theme: "darkTheme",
    data: {}, // Данные подкатегорий
    homeTitle: 'База знаний',
    homeDescription: 'Ваш путь в мир IT',
    homeCategories: null, // Данные о категориях главной страницы
    isModalOverlayOpen: false,
};

/**
 * Персистентный слайс главной страницы и категорий
 * @type {PersistSlice}
 */
const categorySlice = PersistSliceManager.create()
    .setName('site')
    .setInitialState(initialState)
    .setUrl('/category')
    .addAction('toggleTheme', toggleThemeAction)
    .addAction('toggleFocus', toggleFocusAction)
    .addAction('toggleModalOverlay', toggleModalOverlayAction)
    .addCases(CaseCreator.create() //Кейсы категорий
        .setLoader(categoryLoader)
        .setFulfilled(categoryFulfilled)
        .build())
    .addCases(CaseCreator.create() //Кейсы главной страницы
        .setLoader(homePageLoader)
        .setStateVariable('homeCategories')
        .build())
    .setPersistKey('category') // Ключ в localstorage
    .setBlackList([ //Данные, которые не нужно сохранять в localstorage
        'url',
        'homeTitle',
        'homeDescription',
        'isLoading',
        'isError',
        'isModalOverlayOpen',
    ])
    .setTransformBlackList(['theme', 'focus']) // Данные без ограничения по времени хранения
    .build();

export const {toggleTheme, toggleFocus, toggleModalOverlay} = categorySlice.actions;
export default categorySlice.reducer;