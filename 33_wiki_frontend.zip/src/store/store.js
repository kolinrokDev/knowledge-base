import { configureStore } from "@reduxjs/toolkit";
import dictionaryReducer from "../features/dictionary/dictionarySlice";
import articleSlice from "../features/article/articleSlice";
import feedbackSlice from "../features/feedback/feedbackSlice";
import accessReducer from "../features/access/accessSlice";
import petProjectsReducer from "../features/petProjects/petProjectsSlice.js";
import teamRegistrationReducer from "../features/teamRegistration/teamRegistrationSlice";
import categorySlice from "../features/managementSiteSlice.js";
import faqSlice from "../features/faq/faqSlice.js";
import hiringAlgorithmSlice from "../features/hiringAlgorithm/hiringAlgorithmSlice.js";

export const store = configureStore({
  reducer: {
    site: categorySlice,
    dictionary: dictionaryReducer,
    feedback: feedbackSlice,
    faq: faqSlice,
    hiringAlgorithm: hiringAlgorithmSlice,
    article: articleSlice,
    access: accessReducer,
    petProjects: petProjectsReducer,
    teamRegistration: teamRegistrationReducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    serializableCheck: {
      ignoreActions: ['persist/PERSIST']
    }
  }),
});
