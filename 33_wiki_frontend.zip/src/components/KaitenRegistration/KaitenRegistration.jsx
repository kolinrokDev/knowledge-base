import styles from "./KaitenRegistration.module.scss";
import { useSelector } from "react-redux";
import Markdown from "react-markdown";
import { getCorrectImageSrc } from "../../supports/apiUtils";
import PagePreloader from "../UI/preloaders/PagePreloader";

function KaitenRegistration ({ article }) {
    const { theme } = useSelector((state) => state.site);

    // Функция для добавления ведущего нуля
    const addZeroIfSingleDigit = (num) => (num >= 1 && num <= 9 ? `0${num}` : num);

    // Функция для обработки Markdown
    const formatMarkdown = (markdown) => {
        if (!markdown) return "";
        // Заменяем обратные слэши на прямые
        return markdown.replace(/\\/g, "/");
    };

    const renderMarkdown = (markdown) => (
            <Markdown
              components={{
                img: ({ src, alt }) => (
                  <img
                    src={getCorrectImageSrc(src)}
                    alt={alt || "image"}
                    className={`${styles.image} `}
                  />
                ),
              }}
            >
              {formatMarkdown(markdown)}
            </Markdown>
        );

    // Проверяем наличие данных
    if (!article || !article.article_text || article.article_text.length < 2) {
        return <PagePreloader />;
    }

    // Первая часть текста (правила)
    const rules = article.article_text[0]?.body.split("\r\n") || [];

    // Вторая часть текста (шаги)
    const steps = article.article_text[1]?.body.split("\r\n") || [];

    return (
        <div
            className={`${styles.kaitenRegistration__section} ${
            theme === "darkTheme" ? styles.title_dark : styles.title_light
            } container`}
        >
            <h2 className={`${styles.kaitenRegistration__title}`}>{article.title || "Регистрация в Kaiten"}</h2>

            <ul className={`${styles.rules} ${theme === "darkTheme" ? styles.rules__dark : styles.rules__light}`}>
                {rules.map((line, index) => (
                        <li
                            className={`${styles.rules__item} ${
                                theme === "darkTheme"
                                    ? styles.rules__item__dark
                                    : styles.rules__item__light
                            }`}
                            key={index}
                        >
                            {/* SVG вместо номера */}
                            <svg
                                width="8"
                                height="20"
                                viewBox="0 0 8 20"
                                fill="CurrentColor"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M0.0616538 4.0953C-0.346466 1.96718 1.3234 0 3.538 0C5.7526 0 7.42248 1.96718 7.01437 4.0953L5.55685 11.6952C5.37468 12.645 4.52643 13.3333 3.538 13.3333C2.54957 13.3333 1.70131 12.645 1.51915 11.6952L0.0616538 4.0953ZM6.09503 17.5C6.09503 18.8807 4.95021 20 3.538 20C2.12578 20 0.98096 18.8807 0.98096 17.5C0.98096 16.1193 2.12578 15 3.538 15C4.95021 15 6.09503 16.1193 6.09503 17.5Z"
                                    fill="CurrentColor"
                                />
                            </svg>
                            {/* Текст из строки */}
                            <Markdown>{line}</Markdown>
                        </li>
                    ))}
            </ul>

            <div className={`${styles.kaitenRegistration__invite} ${styles.invite}`}>
                <p className={`${styles.invite__before}`}>
                    Как отправить приглашение в Kaiten
                </p>
                <ul className={styles.invite__stepsList}>
                    {steps.map((line, index) => (
                                <li
                                    className={styles.invite__step}
                                    key={index}
                                >
                                    <span
                                        className={`${styles.invite__number} ${
                                            theme === "darkTheme"
                                                ? styles.invite__number__dark
                                                : styles.invite__number__light
                                        }`}
                                    >
                                        {addZeroIfSingleDigit(index + 1)}
                                    </span>
                                    <div className={styles.invite__box}>
                                            {renderMarkdown(line)} {/* Обрабатываем каждую строку Markdown */}
                                    </div>
                                </li>
                            ))}
                </ul>
                <p className={`${styles.invite__after}`}>
                    Готово! Приглашение отправлено
                </p>
            </div>        
        </div>
    );
}

export default KaitenRegistration;
