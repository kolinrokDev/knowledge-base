import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchDictionary } from "../../features/dictionary/dictionarySlice";
import PagePrealoder from "../UI/preloaders/PagePreloader";
import styles from "./DictionaryPage.module.scss"

function DictionaryMain() {
    const dispatch = useDispatch();
    const { theme } = useSelector((state) => state.site); // Получение текущей темы сайта из состояния Redux
    const { dictionary, status, error } = useSelector((state) => state.dictionary);

    useEffect(() => {
        dispatch(fetchDictionary());
    }, [dispatch]);

    // Массив цветов для раскрашивания слов темная тема
    const colorWordArrayDarkTheme = [
        "#FAC863",
        "#88C6BE",
        "#C5A5C5",
        "#8DC891",
        "#FC929E",
        "#5A9BCF",
    ];

    // Массив цветов для раскрашивания слов светлая тема
    const colorWordArrayLightTheme = [
        "#39AD3C",
        "#CF6D28",
        "#0D9389",
        "#38589E",
        "#CC34C5",
        "#4B8BBE",
    ];

    // Функция для генерации цветов
    const generateColorMap = (dictionary, theme) => {
        const colors = theme === "darkTheme" ? colorWordArrayDarkTheme : colorWordArrayLightTheme;
        return dictionary.map((item, index) => ({
            ...item,
            color: colors[index % colors.length],
        }));
    };

    // Сортировка слов по алфавиту
    const sortedData = [...(dictionary || [])].sort((a, b) => a.word.localeCompare(b.word));

    // Генерация цветов для словаря
    const coloredDictionary = generateColorMap(sortedData, theme);

    return (
        <>
        <div className={`${styles.dictionary} ${
            theme === "darkTheme" ? styles.dictionary_dark : styles.dictionary_light
        } container`}>
            <h1 className={styles.dictionary__title}>Словарь терминов разработчиков</h1>
            {status === "loading" && <PagePrealoder/>}
            {error && <p className={styles.error}>Ошибка: {error}</p>}
            <div className={styles.dictionary__wordsBox}>
                    {coloredDictionary.map((item) => (
                        <p className={styles.dictionary__wordsBox__word}
                            key={item.id}
                        >
                            {/* Ссылка на термин или просто текст, если ссылки нет */}
                            <a
                                className={`${styles.dictionary__wordsBox__word__link} ${
                                    item.url ? styles.hasLink : styles.noLink
                                }`}
                                href={item.url || "#"}
                                target={item.url ? "_blank" : undefined}
                                style={{ color: item.color }}
                            >
                                <span>{item.word}</span>
                            </a>{" "}
                            - {item.description}
                        </p>
                    ))}
            </div>
        </div>
        </>
    );
}

export default DictionaryMain;