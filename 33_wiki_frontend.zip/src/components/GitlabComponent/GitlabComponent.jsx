import React, { useEffect } from "react";
import ReactMarkdown from "react-markdown";
import styles from "./gitlabComponent.module.scss";
import "../../styles/App.scss";
import CloudDownloadIcon from "../UI/svg/CloudDownloadIcon";
import { getCorrectImageSrc } from "../../supports/apiUtils";

function GitlabComponent({ article, theme }) {
  const formatMarkdown = (markdown) => {
    if (!markdown) return "";

    // Заменяем обратные слэши на прямые
    return markdown.replace(/\\/g, "/");
  };

  const renderMarkdown = (markdown) => (
    <ReactMarkdown
      components={{
        img: ({ src, alt }) => (
          <img
            src={`${getCorrectImageSrc(src)}${
              theme === "darkTheme" ? ".png" : "_ligth.png"
            }`}
            alt={alt || "image"}
            className={`${styles.image} ${
              theme === "darkTheme" ? "" : styles.image_ligth
            }`}
          />
        ),
        a: ({ href, children }) => (
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className={styles.link}
          >
            {children}
          </a>
        ),
      }}
    >
      {formatMarkdown(markdown)}
    </ReactMarkdown>
  );

  return (
    <>
      <div
        className={`${styles.gitlabBox} ${
          theme === "darkTheme" ? "" : styles.gitlabBox__ligth
        } container`}
      >
        {article && (
          <>
            {/* Заголовок статьи */}
            <div className={`${styles.gitlabBox__titleBox}`}>
              <h1 className={`${styles.gitlabBox__titleBox__title}`}>
                {article.title}
              </h1>
              <a className={`${styles.gitlabBox__titleBox__download}`} href="/documents/how_to_use_Gitlab.pdf" download>
                <CloudDownloadIcon />
              </a>
            </div>

            {/* Текст из описания с телом статьи */}
            {article.description && (
              <div
                className={`${styles.gitlabBox__items} ${
                  theme === "darkTheme" ? "" : styles.gitlabBox__items__ligth
                }`}
              >
                <h2 className={`${styles.gitlabBox__items__title}`}>
                  {console.log("image", article.images[1])}
                  {article.description}
                </h2>
                <p className={`${styles.gitlabBox__items__text}`}>
                  {renderMarkdown(article.body)}
                </p>
              </div>
            )}

            {/* Тексты статьи с заголовками */}
            {article.article_text ? (
              <>
                {" "}
                {article.article_text.map((section, index) => (
                  <div
                    className={`${styles.gitlabBox__items} ${
                      theme === "darkTheme"
                        ? ""
                        : styles.gitlabBox__items__ligth
                    }`}
                    key={index}
                  >
                    <h2 className={`${styles.gitlabBox__items__title}`}>
                      {section.title}
                    </h2>
                    <p className={`${styles.gitlabBox__items__text}`}>
                      {renderMarkdown(section.body)}
                    </p>
                  </div>
                ))}{" "}
              </>
            ) : (
              ""
            )}
          </>
        )}
      </div>
    </>
  );
}

export default GitlabComponent;
