import React, { useState } from "react";
import styles from "./Footer.module.scss";
import PrivacyPolicyModal from "../PrivacyPolicyModal/PrivacyPolicyModal";
import "../../styles/App.scss";
import { useDispatch, useSelector } from "react-redux";
import { toggleModalOverlay } from "../../features/managementSiteSlice";

function Footer() {
  const dispatch = useDispatch();
  const { theme, isModalOverlayOpen } = useSelector((state) => state.site);
  const [isModalOpen, setModalOpen] = useState(false);


  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

  return (
    <footer className={`${styles.footer} container ${theme === "darkTheme" ? "" : styles.footer__light
            }`}>

      <div className={`${styles.footer__left} `}>
        <a href="https://guild-of-developers.ru/"
          className={`${styles.footer__link} ${theme === "darkTheme" ? "" : styles.footer__link__light
            }`}
        >&copy; GOD.</a>
        <p
          className={`${styles.footer__text}`}>
          &nbsp;Все права защищены
        </p>
      </div>

      <div className={styles.footer__right}>
        <a
          className={`${styles.footer__link} ${theme === "darkTheme" ? "" : styles.footer__link__light
            }`}
          onClick={openModal}
        >
          Политика конфиденциальности
        </a>

        {/* модалка начало */}
        <div className={`${styles.footer__feedback} ${theme === "darkTheme" ? "" : styles.footer__feedback_light}`} onClick={() => dispatch(toggleModalOverlay(!isModalOverlayOpen))}>
          <svg className={`${styles.footer__feedback__svg} ${theme === "darkTheme" ? "" : styles.footer__feedback__svg_light}`} width="21.000488" height="17.000366" viewBox="0 0 21.0005 17.0004" fill="none" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
            <path id="Vector" d="M16.4 14.1C14.1 15.6 9.97 15.86 7.77 15.44C5.58 15.02 3.64 13.99 2.31 12.53C0.98 11.07 0.35 9.28 0.52 7.48C0.7 5.68 1.67 3.99 3.27 2.71C4.87 1.44 6.98 0.66 9.23 0.52C11.48 0.38 13.72 0.89 15.54 1.95C17.37 3.01 18.66 4.56 19.18 6.32C19.7 8.07 19.42 9.92 18.39 11.53L20.5 16.5L16.4 14.1Z" fill="#55C3E4" fillOpacity="0.800000" fillRule="nonzero" />
            <path id="Vector" d="M7.77 15.44C5.58 15.02 3.64 13.99 2.31 12.53C0.98 11.07 0.35 9.28 0.52 7.48C0.7 5.68 1.67 3.99 3.27 2.71C4.87 1.44 6.98 0.66 9.23 0.52C11.48 0.38 13.72 0.89 15.54 1.95C17.37 3.01 18.66 4.56 19.18 6.32C19.7 8.07 19.42 9.92 18.39 11.53L20.5 16.5L16.4 14.1C14.1 15.6 9.97 15.86 7.77 15.44Z" stroke="#21AED8" strokeOpacity="0.500000" strokeWidth="1.000000" strokeLinejoin="round" />
          </svg>
        </div>
        {/* модалка конец */}

      </div>

      <PrivacyPolicyModal isOpen={isModalOpen} onClose={closeModal} />
    </footer>
  );
}

export default Footer;
