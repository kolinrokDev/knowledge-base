import { useState } from "react";
import ButtonNavigation from "../UI/buttons/ButtonNavigation/ButtonNavigation";
import styles from "./navigation.module.scss";
import FirstContactModal from "../FirstContactModal/FirstContactModal";
import {Link, useNavigate} from "react-router-dom";
import SelectedColorButtonNavigation from "../UI/buttons/ButtonNavigation/SelectedColorButtonNavigation.jsx";

/**
 * Блок навигации по категориям
 * @param customNavigationData {[{}]} список элементов навигации
 * @param colorTheme {string} цветовое обозначение темы кнопок навигации
 * @param minQuantityButtons {number} минимальное число отображаемых кнопок
 * @returns {JSX.Element}
 * @constructor
 */
const Navigation = ({ customNavigationData, colorTheme = 'blue', minQuantityButtons = 12}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();

  //Заглушки пустых кнопок (кнопки с таксой)
  const btnStubs = [];

  //Заполнение массива пустых кнопок
  for (let i = 0; i < minQuantityButtons - customNavigationData.length; i++) {
    btnStubs.push(<SelectedColorButtonNavigation color={colorTheme}/>);
  }

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  /**
   * Переход по нажатию на клавишу Enter
   * @param e
   * @param link
   */
  const pressEnter = (e, link) => {
    if (e.key === "Enter") {
      navigate(link);
    }
  };

  return (
    <div className={`${styles.navBox}`}>
      <nav className={`${styles.navigation}`}>
        {customNavigationData.map((item, index) => {
          if (item.name === 'Первый контакт') {
            return (
              <div key={index} onClick={openModal} className={styles.modalButton}>
                <SelectedColorButtonNavigation title={item.name}/>
              </div>
            );
          }

          //Переход по ссылке на целевую страницу или запрос списка подкатегорий выбранной категории
          const href = item.link ? item.link : `/category/${item.id}`;
          return (
            <Link to={href} key={index} tabIndex={-1}
                  onKeyDown={(e) => pressEnter(e, href)}>
              <SelectedColorButtonNavigation title={item.name} color={colorTheme}/>
            </Link>
          );
        })}
        {...btnStubs}
      </nav>
      {isModalOpen && <FirstContactModal closeModal={closeModal} />}
    </div>
  );
};

export default Navigation;
