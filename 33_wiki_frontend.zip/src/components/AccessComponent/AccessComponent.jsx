import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchTables } from "../../features/access/accessSlice";
import styles from './accessComponent.module.scss';
import "../../styles/App.scss";
import SliderControls from "../UI/Slider/SliderControls";
import PagePrealoder from "../UI/preloaders/PagePreloader";

const AccessComponent = () => {
    const dispatch = useDispatch();
    const { theme } = useSelector((state) => state.site);
    const { tables, status, error } = useSelector((state) => state.access);

    const [activeColumns, setActiveColumns] = useState({});
    const tdClass = theme === "darkTheme" ? styles.td_dark : styles.td_light;

    // Иконки для таблиц
    const tableIcons = {
        "Доступы GoD": [
            { icon: "/img/access/pm_icon.svg", label: "" },
            { icon: "/img/access/design_icon.svg", label: "" },
            { icon: "/img/access/developer_icon.svg", label: "" },
        ],
        "Уровни доступа": [
            { icon: "/img/access/pm_icon.svg", label: "" },
            { icon: "/img/access/developer_icon.svg", label: "" },
            { icon: "/img/access/teamlead_icon.svg", label: "" },
            { icon: "/img/access/design_icon.svg", label: "" },
        ],
    };

    useEffect(() => {
        dispatch(fetchTables());
    }, [dispatch]);

    // Функция для обновления activeColumn конкретной таблицы
    const handleColumnChange = (tableName, newColumn) => {
        setActiveColumns((prev) => ({
            ...prev,
            [tableName]: newColumn,
        }));
    };

    const DesktopTable = ({ rows, headers, styleClass }) => (
        <table className={styleClass}>
            <thead>
                <tr>
                    <th></th>
                    {headers.map((header, index) => (
                        <th key={index}>
                            <div className={styles.th_item}>
                                <img src={header.icon} alt={`${header.label} Icon`} />
                                {header.label}
                            </div>
                        </th>
                    ))}
                </tr>
            </thead>
            <tbody>
                {rows.map((row, rowIndex) => (
                    <tr key={rowIndex}>
                        <td className={`${styles.td} ${tdClass}`}>
                            <div className={styles.td_item_row}>{row.row}</div>
                        </td>
                        {row.cells.map((value, colIndex) => (
                            <td className={`${styles.td} ${tdClass}`} key={colIndex}>
                                <div className={styles.td_item}>{value}</div>
                            </td>
                        ))}
                    </tr>
                ))}
            </tbody>
        </table>
    );

    const ScrollIndicator = ({ headers, activeColumn }) => (
        <div className={styles.scrollIndicator}>
            {headers.map((_, index) => (
                <div
                    key={index}
                    className={`${styles.indicatorDot} ${index === activeColumn ? styles.active : ""}`}
                />
            ))}
        </div>
    );

    const isButtonDisabled = (direction, activeColumn, headers) => {
        if (direction === -1) return activeColumn === 0;
        if (direction === 1) return activeColumn === headers.length - 1;
        return false;
    };

    const MobileTable = ({ rows, styleClass, activeColumn, tdClass }) => (
        <table className={styleClass}>
            <tbody>
                {rows.map((row, rowIndex) => (
                    <tr key={rowIndex}>
                        <td className={`${styles.td} ${tdClass} ${styles.td_item_row}`}>{row.row}</td>
                        <td className={`${styles.td} ${tdClass} ${styles.td_item}`}>
                            {row.cells[activeColumn]}
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );

    return (
        <section
            className={`${styles.section_access} ${theme === "darkTheme" ? styles.text_dark : styles.text_light
                } container`}
        >
            {status === "loading" && <PagePrealoder/>}
            {error && <p className={styles.error}>Ошибка: {error}</p>}

            {tables.length > 0 ? (
                tables
                    .filter((table) => table.table_name === "Доступы GoD" || table.table_name === "Уровни доступа") // Фильтрация
                    .map((table) => {
                        const activeColumn = activeColumns[table.table_name] || 0;
                        return (
                            <div key={table.table_name} className={styles.access}>
                                <h1 className={styles.title}>{table.table_name}</h1>
                                {table.table_name === "Доступы GoD" && (
                                    <p className={styles.subtitle}>Запрашивает PM, через комнату проекта в Element</p>
                                )}

                                <div className={`${styles.desktopTable}`}>
                                    <DesktopTable
                                        rows={table.rows}
                                        headers={tableIcons[table.table_name] ? tableIcons[table.table_name].map((icon, index) => ({
                                            ...icon,
                                            label: table.columns?.[index] || "",
                                        })) : []}
                                        styleClass={
                                            table.table_name === "Доступы GoD"
                                                ? styles.table_access
                                                : styles.table_levels
                                        }
                                    />
                                </div>

                                <div className={`${styles.mobileTable}`}>
                                    <>
                                        <SliderControls
                                            headers={tableIcons[table.table_name] ? tableIcons[table.table_name].map((icon, index) => ({
                                                ...icon,
                                                label: table.columns?.[index] || "",
                                            })) : []}
                                            activeColumn={activeColumn}
                                            onColumnChange={(newColumn) =>
                                                handleColumnChange(table.table_name, newColumn)
                                            }
                                            theme={theme}
                                            isButtonDisabled={(direction) =>
                                                isButtonDisabled(direction, activeColumn, table.columns || [])
                                            }
                                        />
                                        <ScrollIndicator
                                            headers={table.columns || []}
                                            activeColumn={activeColumn}
                                        />
                                        <MobileTable
                                            rows={table.rows}
                                            headers={table.columns || []}
                                            styleClass={
                                                table.table_name === "Доступы GoD"
                                                    ? styles.table_access
                                                    : styles.table_levels
                                            }
                                            activeColumn={activeColumn}
                                            tdClass={tdClass}
                                        />
                                    </>
                                </div>
                            </div>
                        );
                    })
            ) : (
                <p>Нет данных для отображения</p>
            )}
            <div className={styles.clarification}>
                <p>
                    Все доступы запрашиваются PM проекта через мессенджер Element (кроме токена): тегнуть нужного человека, название доступа, никнейм/эл.почта, специальность, название проекта. Пример: @MicoDi: Доступ в Element, Kolyasnami:@guild-of-developers,ru, фронт, проект База Знаний или @MicoDi: Доступ в GitLab, Kolin-nik-v-GL, фронт, проект База Знаний
                </p>
                <p>
                    **При регистрации в GitLab (https://gitlab.guild-of-developers.ru/) создаем новый аккаунт, существующий не подойдет. Тимлиду проекта выдаются права - Maintainer В дальнейшем тимлид сам добавляет в проект разработчика после его аппрува.
                </p>
                <ul>
                    <li>Web-версия Element<a>https://matrix.guild-of-developers.ru</a></li>
                    <li>Моб.версия Element<a>https://matrix.guild-of-developers.ru</a></li>
                    <li>GitLab<a>https://gitlab.guild-of-developers.ru/</a></li>

                </ul>
            </div>
        </section>
    );
};

export default AccessComponent;
