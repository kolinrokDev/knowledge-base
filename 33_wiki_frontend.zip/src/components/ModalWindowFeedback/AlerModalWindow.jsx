import React from "react";
import styles from "./AlerModalWindow.module.scss";
const AlerModalWindow = () => {
  return (
    <div className={styles.fon}>
      <div className="">
        <div className={styles.title}>Обращение отправлено</div>
        <div className={styles.discription}>
          Наш куратор ответит Вам в Element
        </div>
        <button className={styles.button}>ОК</button>
      </div>
    </div>
  );
};

export default AlerModalWindow;
