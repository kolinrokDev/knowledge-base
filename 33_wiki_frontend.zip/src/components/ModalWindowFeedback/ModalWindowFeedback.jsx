import styles from "./ModalWindowFeedback.module.scss";
import { useDispatch, useSelector } from "react-redux";
import { useState } from "react";
import { toggleModalOverlay } from "../../features/managementSiteSlice";
import { Form, Formik, Field } from "formik";
import { fetchFeedback } from "../../features/feedback/feedbackSlice";
import { feedbackValidationSchema } from "../../validations/feedbackValidationSchema"

const options = [
  { key: "frontend", value: "Frontend разработчик" },
  { key: "backend", value: "Backend разработчик" },
  { key: "tester", value: "Тестировщик" },
  { key: "project", value: "Project-менеджер" },
  { key: "uxui", value: "UX/UI дизайнер" },
  { key: "designer", value: "Графический дизайнер" },
  { key: "teamleed", value: "TeamLeed" },
  { key: "devops", value: "DevOps" },
  { key: "android", value: "Android" },
  { key: "iOS", value: "iOS" },
  { key: "ds", value: "DS" },
  { key: "other", value: "Другое" },
];

const ModalWindowFeedback = () => {
  const dispatch = useDispatch();
  const { theme, isModalOverlayOpen } = useSelector((state) => state.site);
  const { status, error } = useSelector((state) => state.feedback);
  const [isShown, setIsShown] = useState(false);
  const [validateSuccess, setValidateSuccess] = useState(false);


  const handleClickOverlay = () => {
    dispatch(toggleModalOverlay(!isModalOverlayOpen));
  };

  const handleClick = () => {
    setIsShown(!isShown)
  }

  const handleClickChoose = (value, setFieldValue) => {
    setFieldValue("user_role", value); // Устанавливаем значение в Formik
    document.getElementById("title").innerText = value; // Обновляем отображаемый текст
    setIsShown(false); // Сворачиваем список
  };

  const formikInitialValues = {
    username: "",
    user_role: "",
    project_name: "",
    element_nickname: "",
    question: "",
  };

  let prevValue = '';

  const handleNicknameInput = ({ target }) => {
    const value = target.value.replace(':guild-of-developers.ru', '').replace('@', '');
    const lineLength = value.length;

    if (value === '') {
      target.value = '';
    } else {

      const result = '@' + value + ':guild-of-developers.ru';
      target.value = '';
      target.value = result;

      target.setSelectionRange(lineLength + 1, lineLength + 1);
    }

    if (!target.value.match(/@[A-Za-z0-9]+([A-Za-z0-9-_]+)*:guild-of-developers.ru/)) {
      if (value === '') {
        target.value = '';
      } else {
        target.value = '';
        target.value = prevValue;
        const newValLength = prevValue.replace(':guild-of-developers.ru', '').replace('@', '');
        target.setSelectionRange(newValLength + 1, newValLength + 1);
      }
    } else {
      const result = '@' + value + ':guild-of-developers.ru';
      prevValue = result;
    }
  }


  const formikOnSubmit = async (values, { resetForm }) => {
    try {
      await dispatch(fetchFeedback(values)).unwrap();
      resetForm(); // Сброс формы после успешной отправки
      alert("Обращение отправлено успешно!"); // Вывод сообщения об успехе
    } catch (error) {
      alert(`Ошибка: ${error}`); // Вывод ошибки
    }
    setValidateSuccess(prev => prev = true);
  };

  return !validateSuccess ? (
    <>
      <div className={styles.overlay__controls}>
        <button className={`${styles.overlay__close} ${theme === "darkTheme" ? "" : styles.overlay__close_light}`} onClick={handleClickOverlay}>
          <svg width="26.000000" height="26.000000" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
            <path id="Vector" d="M5.4 5.4C5.66 5.14 6.01 5 6.38 5C6.75 5 7.1 5.14 7.36 5.4L29.55 27.59C29.69 27.72 29.8 27.87 29.87 28.04C29.95 28.21 29.99 28.4 29.99 28.58C30 28.77 29.96 28.95 29.89 29.13C29.82 29.3 29.72 29.46 29.59 29.59C29.46 29.72 29.3 29.82 29.13 29.89C28.95 29.96 28.77 30 28.58 29.99C28.4 29.99 28.21 29.95 28.04 29.87C27.87 29.8 27.72 29.69 27.59 29.55L5.4 7.36C5.14 7.1 5 6.75 5 6.38C5 6.01 5.14 5.66 5.4 5.4Z" fill="#FFFFFF" fillOpacity="1.000000" fillRule="evenodd" />
            <path id="Vector" d="M29.55 5.4C29.81 5.66 29.96 6.01 29.96 6.38C29.96 6.75 29.81 7.1 29.55 7.36L7.36 29.55C7.1 29.8 6.75 29.93 6.39 29.93C6.03 29.92 5.69 29.77 5.43 29.52C5.18 29.27 5.04 28.92 5.03 28.56C5.02 28.2 5.16 27.86 5.4 27.59L27.59 5.4C27.85 5.14 28.21 5 28.57 5C28.94 5 29.29 5.14 29.55 5.4Z" fill="#FFFFFF" fillOpacity="1.000000" fillRule="evenodd" />
          </svg>
        </button>
      </div>

      <div className={`${styles.modal__container} ${theme === "darkTheme" ? "" : styles.modal__container_light
        }`}>

        <div className={`${styles.title} ${theme === "darkTheme" ? "" : styles.title_light}`}>Остались вопросы?</div>
        <div className={`${styles.title__description} ${theme === "darkTheme" ? "" : styles.title__description_light
          }`}>
          Оставьте обращение заполнив поля ниже, и наш куратор ответит Вам в Element
        </div>

        <Formik initialValues={formikInitialValues} onSubmit={formikOnSubmit} validationSchema={feedbackValidationSchema}>
          {({values, errors, touched, setFieldValue }) => (
            <Form id="user-data-form" type="post" className={`${styles.form}`} action="/api/feedback/create/" method="post">
              <label className={`${styles.form__label} ${theme === "darkTheme" ? "" : styles.form__label_light
                }`} htmlFor="username">Имя </label>
              <Field className={`${styles.form__input} ${theme === "darkTheme" ? "" : styles.form__input_light
                } ${values.username.length !==0 && theme === "darkTheme" ? styles.form__input_filled : ""}
                ${values.username.length !==0 && theme !== "darkTheme" ? styles.form__input_light_filled : ""}`} type="text" id="username" name="username" placeholder="Иван" />
              {errors.username && touched.username ? (
                <div className={`${styles.validateError} ${theme === "darkTheme" ? "" : styles.validateError_light}`}>{errors.username}</div>
              ) : null}


              <label className={`${styles.form__label} ${theme === "darkTheme" ? "" : styles.form__label_light
                }`} htmlFor="user_role">Специальность</label>

              <div onClick={handleClick} className={`${styles.select} ${theme === "darkTheme" ? "" : styles.select_light}`}>

                <label id='title'>Выберите</label>

                <div className={`${styles.select__arrow} ${theme === "darkTheme" ? "" : styles.select__arrow_light} ${!isShown ? styles.select__arrow_active : ""}`}>
                  <svg width="8.958069" height="8.958008" viewBox="0 0 8.95807 8.95801" fill="none" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                    <rect id="Rectangle 10" x="8.150330" y="-0.334961" rx="0.807736" width="1.615472" height="11.999494" transform="rotate(45 8.150330 -0.334961)" fill="#D9D9D9" fillOpacity="1.000000" />
                  </svg>
                  <svg width="8.958862" height="8.958984" viewBox="0 0 8.95886 8.95898" fill="none" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                    <rect id="Rectangle 9" x="-0.334534" y="0.807617" rx="0.807658" width="1.615316" height="12.000637" transform="rotate(-45 -0.334534 0.807617)" fill="#D9D9D9" fillOpacity="1.000000" />
                  </svg>
                </div>

                <div className={`${styles.dropDown} ${isShown ? "" : styles.dropDown_hidden} ${theme === "darkTheme" ? "" : styles.dropDown__light}`}>
                  {isShown &&
                    options.map((item, index) => (
                      <div
                        key={index}
                        onClick={() => handleClickChoose(item.value, setFieldValue)}
                        className={`${styles.dropDown__item} ${theme === "darkTheme" ? "" : styles.dropDown__item__light}`}
                      >
                        {item.value}
                      </div>
                    ))}
                </div>
              </div>

              <label className={`${styles.form__label} ${theme === "darkTheme" ? "" : styles.form__label_light
                }`} htmlFor="project_name">Название проекта </label>
              <Field className={`${styles.form__input} ${theme === "darkTheme" ? "" : styles.form__input_light
                } ${values.project_name.length !==0 && theme === "darkTheme" ? styles.form__input_filled : ""}
                ${values.project_name.length !==0 && theme !== "darkTheme" ? styles.form__input_light_filled : ""}`} type="text" name="project_name" placeholder="База знаний" />
                {errors.project_name && touched.project_name ? (
                  <div className={`${styles.validateError} ${theme === "darkTheme" ? "" : styles.validateError_light}`}>{errors.project_name}</div>
                ) : null}

              <label className={`${styles.form__label} ${theme === "darkTheme" ? "" : styles.form__label_light
                }`} htmlFor="element_nickname">Ник в Element</label>
                <Field
                  className={`${styles.form__input} ${
                    theme === "darkTheme" ? "" : styles.form__input_light
                  } ${values.element_nickname.length !==0 && theme === "darkTheme" ? styles.form__input_filled : ""}
                ${values.element_nickname.length !==0 && theme !== "darkTheme" ? styles.form__input_light_filled : ""}`}
                  type="text"
                  name="element_nickname"
                  placeholder="@username:guild-of-developers.ru"
                  onInput={handleNicknameInput}
                />
              {errors.element_nickname && touched.element_nickname && (
                <div
                  className={`${styles.validateError} ${
                    theme === "darkTheme" ? "" : styles.validateError_light
                  }`}
                >
                  {errors.element_nickname}
                </div>
              )}

              <label className={`${styles.form__label} ${theme === "darkTheme" ? "" : styles.form__label_light
                }`} htmlFor="question">Какой у Вас вопрос?</label>
              <Field className={`${styles.form__input} ${theme === "darkTheme" ? "" : styles.form__input_light
                } ${values.question.length !==0 && theme === "darkTheme" ? styles.form__input_filled : ""}
                ${values.question.length !==0 && theme !== "darkTheme" ? styles.form__input_light_filled : ""}
                `} type="text" name="question" placeholder="Текст сообщения" />
                {errors.question && touched.question ? (
                  <div className={`${styles.validateError} ${theme === "darkTheme" ? "" : styles.validateError_light}`}>{errors.question}</div>
                ) : null}

              <button type="submit" className={`${styles.form__button} ${theme === "darkTheme" ? "" : styles.form__button_light
                }`}>
                <p>Отправить</p>
                <div className={styles.button__row}>
                  <svg width="13.086151" height="12.927490" viewBox="0 0 13.0862 12.9275" fill="none" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink"><path id="Vector" d="M2.27 1.5L11.58 1.5L11.58 10.81M1.5 11.42L11.58 1.5" stroke="#FFFFFF" strokeOpacity="1.000000" strokeWidth="3.000000" strokeLinejoin="round" strokeLinecap="round" />
                  </svg>
                </div></button>

            </Form>
          )}
        </Formik>

      </div>
    </>
  ) : (
    <div className={`${styles.alert__container} ${theme === "darkTheme" ? "" : styles.alert__container_light}`}>
      <p className={`${styles.title} ${theme === "darkTheme" ? "" : styles.title_light}`}>Обращение отправлено</p>
      <p className={`${styles.title__description} ${theme === "darkTheme" ? "" : styles.title__description_light
        }`}>Наш куратор ответит Вам в Element</p>
      <button onClick={handleClickOverlay} className={`${styles.form__button} ${theme === "darkTheme" ? "" : styles.form__button_light
        }`}>ОК</button>
    </div>
  );
};

export default ModalWindowFeedback;
