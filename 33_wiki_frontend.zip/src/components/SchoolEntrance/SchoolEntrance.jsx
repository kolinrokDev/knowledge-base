import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";
import Markdown from "react-markdown";
import styles from "./SchoolEntrance.module.scss";
import { getCorrectImageSrc } from "../../supports/apiUtils";
import { addBlueMarkersToArticleConverter } from "../../features/converters/addBlueMarkersToArticleConverter";
import CloudDownloadButton from "../UI/buttons/CloudDownloadButton/CloudDownloadButton";

function SchoolEntrance ({ article }) {
    const { theme } = useSelector((state) => state.site);
    const convertedData = addBlueMarkersToArticleConverter(article.article_text);
    const reversedData = [...convertedData].reverse();

    const formatMarkdown = (markdown) => {
        if (!markdown) return "";
    
        // Заменяем обратные слэши на прямые
        return markdown.replace(/\\/g, "/");
      };
    
      const renderMarkdown = (markdown) => (
        <Markdown
          components={{
            img: ({ src, alt }) => (
              <img
                src={`${getCorrectImageSrc(src)}${
                  theme === "darkTheme" ? ".png" : "_light.png"
                }`}
                alt={alt || "image"}
                className={`${styles.image} ${
                  theme === "darkTheme" ? "" : styles.image_light
                }`}
              />
            ),
            a: ({ href, children }) => (
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className={styles.link}
              >
                {children}
              </a>
            ),
          }}
        >
          {formatMarkdown(markdown)}
        </Markdown>
      );

    return (
        <div
            className={`${styles.schoolEntrance__section} ${
            theme === "darkTheme" ? styles.title_dark : styles.title_light
            } container`}
        >
            <div className={`${styles.schoolEntrance__header}`}>
                <h2 className={`${styles.schoolEntrance__title} ${theme === "darkTheme" ? styles.schoolEntrance__title__dark : styles.schoolEntrance__title__light}`}>
                    {article.title}
                </h2>
                <CloudDownloadButton linkToFile={"/documents/Login_to_school_with_instructions_Element.pdf"} />
            </div>
            <div className={`${styles.schoolEntrance__questionnaire} ${theme === "darkTheme" ? styles.schoolEntrance__questionnaire__dark : styles.schoolEntrance__questionnaire__light}`}>
                <p className={`${styles.questionnaire__description} ${theme === "darkTheme" ? styles.questionnaire__description__dark : styles.questionnaire__description__light}`}>
                    Для регистрации на платформе стажировок нужно заполнить анкету
                </p>
                <NavLink to='#' className={`${styles.questionnaire__link} ${theme === "darkTheme" ? styles.questionnaire__link__dark : styles.questionnaire__link__light}`}>
                    Анкета
                    <svg width="30" height="30" viewBox="0 0 30 30" fill="CurrentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10.6646 6.93454L24.8067 6.93454M24.8067 6.93454L24.8067 21.0767M24.8067 6.93454L9.50049 22" stroke="CurrentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                </NavLink>
            </div>

            <section className={`${styles.list__steps}`}>
                {reversedData.map((article, index) => (
                    <div className={`${styles.list__item__articles} ${theme === "darkTheme" ? styles.list__item__dark : styles.list__item__light}`} article={{...article, id: index}} key={index}>
                        <div className={styles.list__item__article}>
                            <h4 id={`article-${article.id}`}><span className={`${styles.list__item__article__number}`}>{article.title}</span></h4>
                            <div className={`${styles.list__item__article__text} ${theme === "darkTheme" ? styles.list__item__article__text__dark : styles.list__item__article__text__light}`}>
                                {renderMarkdown(article.body)}
                            </div>
                        </div>
                    </div>
                ))}
            </section>
        </div>
    );
}

export default SchoolEntrance;
