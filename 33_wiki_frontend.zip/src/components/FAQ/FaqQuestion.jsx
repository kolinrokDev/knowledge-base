import PeopleWithQuestionIcon from "../UI/svg/FAQ/PeopleWithQuestionIcon.jsx";
import style from './Faq.module.scss';
import FaqAnswerModal from "./FaqAnswerModal.jsx";
import {useEffect, useRef, useState} from "react";
import {useClassNameThemeSwitcher} from "../../hooks/useClassNameThemeSwitcher.js";
import styles from "./Faq.module.scss";
import PropTypes from "prop-types";
import {useEscBtn} from "../../hooks/useEscBtn.js";

/**
 * Активный элемент с вопросом страницы FAQ
 * @param index индекс расположения элемента в списке
 * @param question объект с вопросом и ответом на него {question: "question?", answer: "answer"}
 * @returns {JSX.Element}
 * @constructor
 */
const FaqQuestion = ({index, question}) => {
    const checkbox = useRef();
    const [isChecked, setIsChecked] = useState(false);
    const className = useClassNameThemeSwitcher(styles.faq__question_btn,
                                                styles.faq__question_btn__light,
                                                styles.faq__question_btn__dark);

    /** Закрыть модальное окно */
    const closeModal = () => {
        setIsChecked(false);
    };

    //Закрытие модального окна по нажатию клавиши Esc
    useEscBtn(closeModal);

    return (
        <li className={style.faq__question_box}>
            <label htmlFor={`checkbox-${index}`} className={className}>
                <PeopleWithQuestionIcon/>
                <span>{question.title_question}</span>
            </label>
            <input type="checkbox" name="modal-switcher" id={`checkbox-${index}`} ref={checkbox}
                   className={style.faq__checkbox} checked={isChecked}
                   onChange={() => setIsChecked(!isChecked)}/>
            <FaqAnswerModal answer={question.text_answer} closeModal={closeModal} isChecked={isChecked}/>
        </li>
    );
};

FaqQuestion.propTypes = {
    index: PropTypes.number,
    question: PropTypes.object,
}

export default FaqQuestion;