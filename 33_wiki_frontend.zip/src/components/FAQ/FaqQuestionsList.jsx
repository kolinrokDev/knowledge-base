import style from './Faq.module.scss';
import FaqQuestion from "./FaqQuestion.jsx";

/**
 * Блок со списком вопросов страницы FAQ
 * @param questions массив с вопросами
 * @returns {JSX.Element}
 * @constructor
 */
const FaqQuestionsList = ({questions}) => {
    return (
        <div>
            <ul className={style.faq__question_list}>
                {questions.map((question, index) => <FaqQuestion key={index} index={index}
                                                                 question={question}/>)}
            </ul>
        </div>
    );
};

export default FaqQuestionsList;