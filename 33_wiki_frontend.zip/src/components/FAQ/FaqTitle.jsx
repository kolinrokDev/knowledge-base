import styles from './Faq.module.scss';
import ThinkFrameIcon from "../UI/svg/FAQ/ThinkFrameIcon.jsx";
import {useClassNameThemeSwitcher} from "../../hooks/useClassNameThemeSwitcher.js";
import {useSelector} from "react-redux";

/**
 * Заголовок страницы FAQ
 * @param title текст заголовка
 * @returns {JSX.Element}
 * @constructor
 */
const FaqTitle = ({title}) => {
    const className = useClassNameThemeSwitcher(styles.faq__title, styles.faq__title__light);

    return (
        <h1 className={className}>
            <ThinkFrameIcon/>
            <span>{title}</span>
        </h1>
    );
};

export default FaqTitle;