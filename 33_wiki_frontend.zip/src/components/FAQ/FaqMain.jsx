import styles from "./Faq.module.scss";
import FaqTitle from "./FaqTitle.jsx";
import FaqQuestionsList from "./FaqQuestionsList.jsx";
import {useSelector} from "react-redux";

/**
 * Основной контент страницы FAQ
 * @returns {JSX.Element}
 * @constructor
 */
const FaqMain = () => {
    const title = useSelector(state => state.faq.title);
    const data = useSelector(state => state.faq.data);

    return (
        <main className={styles.faq__main}>
            <FaqTitle title={title}/>
            <FaqQuestionsList questions={data}/>
        </main>
    );
};

export default FaqMain;