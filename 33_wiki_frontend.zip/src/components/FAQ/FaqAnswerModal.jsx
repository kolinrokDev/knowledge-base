import QuotesIcon from "../UI/svg/FAQ/QuotesIcon.jsx";
import styles from "./Faq.module.scss";
import CloseButton from "../UI/buttons/CloseButton.jsx";
import PropTypes from "prop-types";
import {useEffect, useRef} from "react";
import {useClickOutside} from "../../hooks/useClickOutside.js";

/**
 * Модальное окно с ответом на вопрос
 * @param answer ответ на вопрос
 * @param closeModal функция закрытия модального окна
 * @param isChecked значение чекбокса
 * @returns {JSX.Element}
 * @constructor
 */
const FaqAnswerModal = ({answer, closeModal, isChecked}) => {
    const modalWindow = useRef();

    // Отслеживание кликов за пределами модельного окна
    useClickOutside(modalWindow, closeModal, isChecked);

    return (
        <div className={styles.faq__modal} ref={modalWindow}>
            <CloseButton action={closeModal} className={styles.faq__modal_btn}/>
            <QuotesIcon/>
            <p>{answer}</p>
        </div>
    );
};

FaqAnswerModal.propTypes = {
    answer: PropTypes.string,
    closeModal: PropTypes.func
}

export default FaqAnswerModal;