import {useSelector} from "react-redux";
import HiringAlgorithmNavItem from "./HiringAlgorithmNavItem.jsx";
import styles from "./HiringAlgorithm.module.scss";

/**
 * Навигация по страницы Алгоритм найма
 * @returns {JSX.Element}
 * @constructor
 */
const HiringAlgorithmNavigation = () => {
    const {articleList} = useSelector(state => state.hiringAlgorithm.data);

    return (
        <nav className={styles.hiring_algorithm__nav}>
            <ol>
                {articleList.map((item, index) => <HiringAlgorithmNavItem title={item.title} index={index} key={index}/>)}
            </ol>
        </nav>
    );
};

export default HiringAlgorithmNavigation;