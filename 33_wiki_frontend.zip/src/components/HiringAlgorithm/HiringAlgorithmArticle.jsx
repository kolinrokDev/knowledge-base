import styles from "./HiringAlgorithm.module.scss";
import Markdown from "react-markdown";

/**
 * Статья на странице Алгоритм найма
 * @param article
 * @returns {JSX.Element}
 * @constructor
 */
const HiringAlgorithmArticle = ({article}) => {
    return (
        <article id={`article-${article.id}`} className={styles.hiring_algorithm__article}>
            <h4><span>{article.title}</span></h4>
            <Markdown>{article.body}</Markdown>
        </article>
    );
};

export default HiringAlgorithmArticle;