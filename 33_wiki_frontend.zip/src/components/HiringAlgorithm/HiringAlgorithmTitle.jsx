import styles from "./HiringAlgorithm.module.scss";
import {useSelector} from "react-redux";

/**
 * Заголовок страницы Алгоритм найма
 * @returns {JSX.Element}
 * @constructor
 */
const HiringAlgorithmTitle = () => {
    const {title} = useSelector((state) => state.hiringAlgorithm.data);

    return (
        <h1 className={styles.hiring_algorithm__title}><span>{title}</span></h1>
    );
};

export default HiringAlgorithmTitle;