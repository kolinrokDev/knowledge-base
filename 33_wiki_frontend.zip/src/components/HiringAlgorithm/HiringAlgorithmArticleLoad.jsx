import {hiringAlgorithmLoader} from "../../features/hiringAlgorithm/hiringAlgorithmSlice.js";
import HiringAlgorithmMain from "./HiringAlgorithmMain.jsx";
import {useSelector} from "react-redux";
import InjectionData from "../../supports/InjectionData.jsx";

/**
 * Загрузчик страницы Алгоритм найма
 * @returns {JSX.Element}
 * @constructor
 */
const HiringAlgorithmArticleLoad = () => {
    const articleList = useSelector(state => state.article.articlesList);
    const id = articleList.filter((article) => article.title === 'Алгоритм найма')[0]['id'];

    return (
        <InjectionData resource='hiringAlgorithm' loader={hiringAlgorithmLoader} searchKey={id}
                       getStateDataFunction={(resource) => state => state[resource].data}
                       component={() => <HiringAlgorithmMain/>}/>
    );
};

export default HiringAlgorithmArticleLoad;