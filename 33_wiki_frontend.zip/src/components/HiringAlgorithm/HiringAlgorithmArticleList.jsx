import {useSelector} from "react-redux";
import styles from "./HiringAlgorithm.module.scss";
import HiringAlgorithmArticle from "./HiringAlgorithmArticle.jsx";

/**
 * Список статей страницы Алгоритм найма
 * @returns {JSX.Element}
 * @constructor
 */
const HiringAlgorithmArticleList = () => {
    const {articleList} = useSelector(state => state.hiringAlgorithm.data);

    return (
        <section className={styles.hiring_algorithm__articles}>
            {articleList.map((article, index) => <HiringAlgorithmArticle article={{...article, id: index}} key={index}/>)}
        </section>
    );
};

export default HiringAlgorithmArticleList;