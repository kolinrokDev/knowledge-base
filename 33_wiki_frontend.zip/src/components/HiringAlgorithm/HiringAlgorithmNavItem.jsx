import styles from "./HiringAlgorithm.module.scss";
import {HashLink} from "react-router-hash-link";
import ArrowIcon from "../UI/svg/HiringAlgorithm/ArrowIcon.jsx";

/**
 * Элемент навигации на страницы на странице Алгоритм найма
 * @returns {JSX.Element}
 * @constructor
 */
const HiringAlgorithmNavItem = ({title, index}) => {
    return (
        <li className={styles.hiring_algorithm__nav_ol_item}>
            <HashLink to={`#article-${index}`}>{title}<ArrowIcon/></HashLink>
        </li>
    );
};

export default HiringAlgorithmNavItem;