import styles from "./HiringAlgorithm.module.scss";
import HiringAlgorithmTitle from "./HiringAlgorithmTitle.jsx";
import HiringAlgorithmNavigation from "./HiringAlgorithmNavigation.jsx";
import HiringAlgorithmArticleList from "./HiringAlgorithmArticleList.jsx";
import classNames from "classnames";
import {useClassNameThemeSwitcher} from "../../hooks/useClassNameThemeSwitcher.js";

/**
 * Основной контент страницы Алгоритмы Найма
 * @returns {JSX.Element}
 * @constructor
 */
const HiringAlgorithmMain = () => {
    const mainClassName = useClassNameThemeSwitcher(styles.hiring_algorithm__main,
        classNames(styles.hiring_algorithm__main, styles.hiring_algorithm__main__light));

    return (
        <main className={`${mainClassName} container`}>
            <HiringAlgorithmTitle/>
            <HiringAlgorithmNavigation/>
            <HiringAlgorithmArticleList/>
        </main>
    );
};

export default HiringAlgorithmMain;