import React, { useState } from "react";
import styles from "./firstContactModal.module.scss";
import { useSelector } from "react-redux";

function FirstContactModal({ closeModal }) {
  const { theme } = useSelector((state) => state.site);

  const [isOpen, setIsOpen] = useState(true);

  const handleClose = () => {
    setIsOpen(false);
    if (closeModal) {
      closeModal();
    }
  };

  return (
    <>
      {isOpen && (
        <div className={`${styles.modal}`}>
          <div
            className={`${styles.modalContent} ${
              theme === "darkTheme" ? styles.modalContent_dark : styles.modalContent_light
            }`}
          >
            <span
              className={`${styles.close} ${
                theme === "darkTheme" ? styles.close_dark : styles.close_light
              }`}
              onClick={handleClose}
            ></span>
            <p
              className={`${styles.modalText} ${
                theme === "darkTheme" ? styles.modalText_dark : styles.modalText_light
              }`}
            >
              Привет! Меня зовут Имя, Я один из специалистов платформы стажировок GoD. Мы
              получили информацию, что ты хотел бы пройти практику в нашей школе, все верно?
            </p>
          </div>
        </div>
      )}
    </>
  );
}

export default FirstContactModal;