import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchTeamRegistrationData } from "../../features/teamRegistration/teamRegistrationSlice";
import styles from './teamRegistrationComponent.module.scss';
import "../../styles/App.scss";
import CloudDownloadIcon from "../UI/svg/CloudDownloadIcon";
import CheckIcon from "../UI/svg/CheckIcon";
import SliderControls from "../UI/Slider/SliderControls";
import PagePreloader from "../UI/preloaders/PagePreloader";
import ServerOverloadPage from "../../pages/ServerOverloadPage";
import * as XLSX from "xlsx";

const TeamRegistrationComponent = () => {
    const dispatch = useDispatch();
    const { theme } = useSelector((state) => state.site);
    const { data, status, error } = useSelector((state) => state.teamRegistration);
    const [activeColumn, setActiveColumn] = useState(0);

    useEffect(() => {
        dispatch(fetchTeamRegistrationData());
    }, [dispatch]);

    // Определение цвета иконки в зависимости от темы
    const iconColor = theme === "darkTheme" ? "white" : "black";

    if (status === "loading") {
        return <PagePreloader />;
    }
    if (error) {
        return <ServerOverloadPage />;
    }
    if (!data || !Array.isArray(data)) return <p>Нет данных</p>;

    const table = data.find((table) => table.table_name === "Регистрация команды");
    if (!table) return <p>Таблица не найдена</p>;
    const { table_name, table_subname, columns, rows } = table;

    // Иконки для таблиц
    const tableIcons = {
        "Регистрация команды": [
            { icon: "/img/access/pm_icon.svg", label: "" },
            { icon: "/img/access/design_icon.svg", label: "" },
            { icon: "/img/access/developer_icon.svg", label: "" },
        ],
    };

    const isButtonDisabled = (direction) => {
        if (direction === -1) return activeColumn === 0;
        if (direction === 1) return activeColumn === columns.length - 1;
        return false;
    };

    const handleColumnChange = (newColumn) => {
        if (newColumn >= 0 && newColumn < columns.length) {
            setActiveColumn(newColumn);
        }
    };

    const ScrollIndicator = ({ headers }) => (
        <div className={styles.scrollIndicator}>
            {headers.map((_, index) => (
                <div
                    key={index}
                    className={`${styles.indicatorDot} ${index === activeColumn ? styles.active : ""}`}
                />
            ))}
        </div>
    );

    // Функция для генерации и скачивания Excel-файла
    const handleDownload = () => {
        const wsData = [
            ["", ...columns], // Заголовки столбцов
            ...rows.map(row => [
                row.row,
                ...row.cells.map(cell => {
                    if (React.isValidElement(cell)) return "✓";
                    return cell !== null && cell !== undefined ? cell : "";
                }),
            ])
        ];

        const ws = XLSX.utils.aoa_to_sheet(wsData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Team Registration");
        XLSX.writeFile(wb, "Регистрация команды.xlsx");
    };

    return (
        <section className={`${styles.container} ${theme === "darkTheme" ? styles.theme_dark : styles.theme_light} container`}>
            <div className={styles.title_box}>
                <h1 className={styles.title}>{table_name}</h1>
                <button className={styles.download} onClick={handleDownload}>
                    <CloudDownloadIcon />
                </button>
            </div>
            <p className={styles.subtitle}>{table_subname}</p>

            {/* Десктопная версия таблицы */}
            <div className={styles.desktopTable}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th></th>
                            {columns.map((column, index) => (
                                <th key={index}>
                                    <div className={styles.th_item}>
                                        {tableIcons[table_name] && tableIcons[table_name][index] && (
                                            <img
                                                src={tableIcons[table_name][index].icon}
                                                alt={tableIcons[table_name][index].label || "icon"}
                                                className={styles.icon_img}
                                            />
                                        )}
                                        {column}
                                    </div>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {rows.map((row, rowIndex) => (
                            <tr key={rowIndex}>
                                <td>
                                    <div className={styles.td_item_row}>{row.row}</div>
                                </td>
                                {row.cells.map((cell, colIndex) => (
                                    <td key={colIndex}>
                                        <div className={styles.td_item}>
                                            {cell === "✓" ? <CheckIcon color={iconColor} /> : cell}
                                        </div>
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Мобильная версия таблицы */}
            <div className={`${styles.mobileTable}`}>
                <div className={styles.sliderControls_override}>
                    <SliderControls
                        headers={(tableIcons[table_name] || []).map((icon, index) => ({
                            ...icon,
                            label: columns[index] || "",
                        }))}                        
                        activeColumn={activeColumn}
                        onColumnChange={handleColumnChange}
                        theme={theme}
                        isButtonDisabled={isButtonDisabled}
                    />
                </div>

                {/* Скролл-индикатор */}
                <ScrollIndicator headers={columns} />

                {/* Таблица, которая отображает только активную колонку */}
                <table className={styles.table}>
                    <tbody>
                        {rows.map((row, rowIndex) => (
                            <tr key={rowIndex}>
                                <td>
                                    <div className={styles.td_item_row}>{row.row}</div>
                                </td>
                                <td>
                                    <div className={styles.td_item}>
                                        {row.cells[activeColumn] === "✓" ? <CheckIcon color={iconColor} /> : row.cells[activeColumn]}
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </section>
    );
};

export default TeamRegistrationComponent;
