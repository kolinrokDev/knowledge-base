import React from "react";
import ReactMarkdown from "react-markdown";
import styles from "./Interview.module.scss";

const Interview = ({ article, theme }) => {
  const sort = (arraySort) => {
    let arrayText = arraySort.slice(0);
    arrayText.sort(function (a, b) {
      return a.title - b.title;
    });
    return arrayText;
  };

  const formatMarkdown = (markdown) => {
    if (!markdown) return "";
    // Заменяем обратные слэши на прямые
    return markdown.replace(/\\/g, "/");
  };

  const renderMarkdown = (markdown) => (
    <ReactMarkdown
      components={{
        img: ({ src, alt }) => (
          <div className={styles.vector}>
            <img
              src={`https://${
                import.meta.env.VITE_WIKI_APP_API__BASE_URL
              }${src}`} // https:// при локальной разработке убираем
              alt={alt || "image"}
              className={`${styles.image} ${
                theme === "darkTheme" ? "" : styles.image_ligth
              }`}
            />
          </div>
        ),
        a: ({ href, children }) => (
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className={styles.link}
          >
            {children}
          </a>
        ),
      }}
    >
      {formatMarkdown(markdown)}
    </ReactMarkdown>
  );

  const refraktorURL = (params) => {
    return params.slice(0, 4) + "s" + params.slice(4);
  };
  return (
    <>
      <div
        className={`${styles.gitlabBox} ${
          theme === "darkTheme" ? "" : styles.gitlabBox__ligth
        } container`}
      >
        <>
          {/* Заголовок статьи */}
          <div className={`${styles.gitlabBox__titleBox}`}>
            <h1 className={`${styles.gitlabBox__titleBox__title}`}>
              {article.title}
            </h1>
          </div>

          {/* Текст из описания с телом статьи */}

          <div
            className={`${styles.gitlabBox__items} ${
              theme === "darkTheme" ? "" : styles.gitlabBox__items__ligth
            }`}
          >
            <h2 className={`${styles.gitlabBox__items__title}`}>
              {article.description}
            </h2>
            <div className={`${styles.gitlabBox__items__text}`}>
              {renderMarkdown(article.body)}
            </div>
          </div>

          {/* Тексты статьи с заголовками */}
          {article.article_text ? (
            <>
              {" "}
              {sort(article.article_text).map((section, index) => (
                <div
                  className={`${styles.gitlabBox__items} ${
                    theme === "darkTheme" ? "" : styles.gitlabBox__items__ligth
                  }`}
                  key={index}
                >
                  {article.images ? (
                    <div className={styles.number}>
                      <img
                        src={`${refraktorURL(article.images[index].preview)}`}
                      />
                      {/* {index} */}
                    </div>
                  ) : (
                    ""
                  )}
                  <div className={`${styles.gitlabBox__items__text}`}>
                    {renderMarkdown(section.body)}
                  </div>
                </div>
              ))}{" "}
            </>
          ) : (
            ""
          )}
        </>
      </div>
    </>
  );
};

export default Interview;
