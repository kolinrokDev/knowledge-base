import TitleHome from "../UI/TitleHome/TitleHome.jsx";
import SearchBarMain from "../UI/SearchBarMain/SearchBarMain.jsx";
import Navigation from "../Navigation/Navigation.jsx";
import WithHeaderAndFooter from "../../supports/WithHeaderAndFooter.jsx";
import BackgroundContainer from "../UI/BackgroundContainer/BackgroundContainer.jsx";
import HomeHeader from "../Header/HomeHeader.jsx";
import {useSelector} from "react-redux";

/**
 * Основной блок главной страницы
 * @returns {JSX.Element}
 * @constructor
 */
const HomeMain = () => {
    const {homeTitle, homeDescription, homeCategories} = useSelector(state => state.site);

    return (
        <WithHeaderAndFooter background={<BackgroundContainer colorTheme='blue'/>} header={<HomeHeader/>} buttonBack={null}>
            <TitleHome titleTitle={homeTitle} titleInfo={homeDescription}/>
            <SearchBarMain />
            <Navigation customNavigationData={homeCategories} colorTheme='blue' minQuantityButtons={11}/>
        </WithHeaderAndFooter>
    );
};

export default HomeMain;