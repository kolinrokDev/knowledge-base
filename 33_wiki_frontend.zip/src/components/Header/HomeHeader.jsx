import Header from "./Header.jsx";

/**
 * Хедер главной страницы
 * @returns {JSX.Element}
 * @constructor
 */
const HomeHeader = () => {
    return (
        <>
            <Header />
            <div style={{ marginTop: "131px" }}></div>
        </>
    );
};

export default HomeHeader;