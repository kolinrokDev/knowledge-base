import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchPetProjects } from "../../features/petProjects/petProjectsSlice.js"
import styles from "./ProjectsReview.module.scss";
import ProjectReviewCard from "./ProjectReviewCard/ProjectReviewCard.jsx";
import PagePreloader from "../UI/preloaders/PagePreloader.jsx";

const ProjectsReview = () => {
  const dispatch = useDispatch();
  const { petProjects, status, error } = useSelector((state) => state.petProjects);

  useEffect(() => {
          dispatch(fetchPetProjects());
  }, [dispatch]);

  return (
    <div className={`${styles.navBox} container`}>
      {status === "loading" && <PagePreloader/>}
      {status === "failed" && <p>Ошибка: {error}</p>}
      {status === "succeeded" && (
        <nav className={`${styles.navigation} container`}>
          {petProjects.map((item) => (
            <ProjectReviewCard
              key={item.id}
              title={item.title}
              text={item.description}
              img={item.image}
              difficulty={item.difficulty}
              implementeds={item.implemented}
              index={item.id}
            />
          ))}
        </nav>
      )}
    </div>
  )
};
export default ProjectsReview;
