import { useSelector } from "react-redux";
import styles from "./ProjectReviewCard.module.scss";
import { useState } from "react";
import ModalCard from "./ModalCard";

const ProjectReviewCard = ({
  title,
  text,
  img,
  difficulty,
  implementeds,
  index,
}) => {
  const { theme } = useSelector((state) => state.site);
  const [modal, setModal] = useState(false);
  const toggleModal = () => setModal(!modal);

  return (
    <>
      <div className={`${styles.card} ${theme === "darkTheme" ? styles.card__dark : styles.card__light}`}>
        <a>
          <div className="card__title_wrapper">
            <h3 className={`${styles.card__title} ${theme === "darkTheme" ? styles.card__title_dark : styles.card__title_light}`}>
              {title}
            </h3>

            <div className={styles.detailsBlock}>
              <div className={`${styles.summary} ${theme === "darkTheme" ? styles.summary__dark : styles.summary__ligth} `}
                onClick={toggleModal}
              >
                <p>подробнее</p>
                <div className={`${theme === "darkTheme"
                      ? styles.summary__dark_svg
                      : styles.summary__ligth_svg
                  } 
                  ${modal && styles.rotate}`}
                ></div>
              </div>
              {modal && (
                <ModalCard
                textModal={text}
                implementedsModal={implementeds}
                difficultyModal={difficulty}
                />
              )}
            </div>

            <p className={`${styles.card__text} ${theme === "darkTheme" ? styles.card__text_dark : styles.card__text_light}`}>
              {text}
            </p>
          </div>
          <div className={styles.card__content_wrapper}>
            <div className={styles.img} style={{ backgroundImage: `url(${img})` }} id={index}/>
            <div className={`${styles.contentBox} ${theme === "darkTheme" ? styles.contentBox__dark : styles.contentBox__light}`}>
              <div className={`${theme === "darkTheme" ? "" : styles.titleCard}`}>
                <h4 className={styles.titleCard__text}>На проекте реализовано:</h4>
                  <pre className={`${styles.list__item} ${theme === "darkTheme" ? "" : styles.list__item_light}`}>
                    {implementeds}
                  </pre>
              </div>

              <div className={`${theme === "darkTheme" ? "" : styles.titleCard}`}>
                <p className={styles.list__item}>Уровень сложности: {difficulty}/10</p>
              </div>
            </div>
          </div>
        </a>
      </div>
    </>
  );
};
export default ProjectReviewCard;
