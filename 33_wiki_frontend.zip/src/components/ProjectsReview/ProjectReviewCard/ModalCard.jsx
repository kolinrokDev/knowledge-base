import React from "react";
import styles from "./ModalCard.module.scss";
const ModalCard = ({ textModal, implementedsModal, difficultyModal }) => {
  return (
    <>
      <div className={styles.modal}>
        <div className={styles.details}>
          <div className={styles.tabletText}>{textModal}</div>
          <div className={styles.tabletTitle}>
            <h4 className={styles.tabletTitle__text}>На проекте реализовано:</h4>
            <pre className={styles.tabletlist}>{implementedsModal}</pre>
            <div className={styles.difficulty}><p>Уровень сложности: {difficultyModal}/10</p></div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ModalCard;
