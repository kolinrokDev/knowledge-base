import {HashLink} from "react-router-hash-link";
import ArrowIcon from "../svg/HiringAlgorithm/ArrowIcon.jsx";
import styles from './AnchorNavItem.module.scss';
import GrayOpacityFrame from "../Frame/GrayOpacityFrame.jsx";
import {useClassNameThemeSwitcher} from "../../../hooks/useClassNameThemeSwitcher.js";

/**
 * Элемент навигации по странице с якорной ссылкой
 * @param item
 * @param index
 * @param prefix префикс идентификатора по которому осуществляется якорная ссылка
 * @returns {JSX.Element}
 * @constructor
 */
const AnchorNavItem = ({title, index, prefix = 'article-'}) => {
    const itemClassName = useClassNameThemeSwitcher(styles.item, styles.item__light, styles.item__dark);

    return (
        <li className={itemClassName}>
            <GrayOpacityFrame light='hover'>
                <HashLink to={`#${prefix}${index}`}>{title}<ArrowIcon/></HashLink>
            </GrayOpacityFrame>
        </li>
    );
};

export default AnchorNavItem;