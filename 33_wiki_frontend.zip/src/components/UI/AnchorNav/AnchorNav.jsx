import styles from './AnchorNav.module.scss';
import AnchorNavItem from "./AnchorNavItem.jsx";

/**
 * Навигация по странице с якорными ссылками
 * @param items список статей (в каждом обязательно должна быть переменная title)
 * @param gap отступ между элементами (по умолчанию 15px)
 * @returns {JSX.Element}
 * @constructor
 */
const AnchorNav = ({items, gap = '15px'}) => {
    return (
        <menu className={styles.anchor_nav} style={{gap}} >
            {items.map((item, index) => <AnchorNavItem title={item.title} key={index} index={index}/>)}
        </menu>
    );
};

export default AnchorNav;