import GrayOpacityFrame from "../Frame/GrayOpacityFrame.jsx";
import style from "./AnchoredTitle.module.scss";

/**
 * Заголовок с якорной ссылкой
 * @param title
 * @param index
 * @param prefix префикс идентификатора по которому осуществляется якорная ссылка
 * @returns {JSX.Element}
 * @constructor
 */
const AnchoredTitle = ({title, index, prefix = 'article-'}) => {
    return (
        <GrayOpacityFrame light='always'>
            <h4 id={prefix + index} className={style.title}>
                <span>
                    {title}
                </span>
            </h4>
        </GrayOpacityFrame>
    );
};

export default AnchoredTitle;