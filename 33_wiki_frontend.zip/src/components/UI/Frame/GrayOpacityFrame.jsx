import style from './GrayOpacityFrame.module.scss';
import classNames from "classnames";

/**
 * Элемент-обёртка, создаёт серую прозрачную рамку вокруг вложенных элементов
 * @param light режим подсветки вокруг рамки (доступно три режима: none, hover, always)
 * @param children
 * @returns {JSX.Element}
 * @constructor
 */
const GrayOpacityFrame = ({light = 'none', children}) => {
    const lightClassNames = {
        none: '',
        hover: style.frame__hover,
        always: style.frame__always
    };

    const frameClassNames = classNames(style.frame, lightClassNames[light]);

    return (
        <div className={frameClassNames}>
            {children}
        </div>
    );
};

export default GrayOpacityFrame;