import { useCallback } from 'react';
import styles from "./BackWardButton.module.scss";
import { useSelector } from "react-redux";
import { useNavigate} from "react-router-dom";

const BackwardButton = () => {
    const { theme } = useSelector((state) => state.site);
    const navigate = useNavigate();

    const handleBack = useCallback(() => {
		navigate(-1);
	}, [navigate]);

    return (
        <div className={`${styles.buttonBox} container `}>
        <div onClick={handleBack} className={`${styles.button} ${theme === "darkTheme" ? "" : styles.button_light}`}>
            <svg width="5.718262" height="7.66" viewBox="0 0 5.71826 10.4023" fill="none" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">

                <path id="Union" d="M5.56592 0.150879C5.36475 -0.050293 5.03857 -0.050293 4.8374 0.150879L0.150879 4.8374C-0.050293 5.03857 -0.050293 5.36475 0.150879 5.56592C0.160645 5.57568 0.170898 5.58496 0.180664 5.59375L4.83838 10.251C5.03955 10.4526 5.36572 10.4526 5.56738 10.251C5.76855 10.0498 5.76855 9.72363 5.56738 9.52197L1.24561 5.20068L5.56592 0.879883C5.76758 0.678711 5.76758 0.352539 5.56592 0.150879Z" clipRule="evenodd" fill="#454545" fillOpacity="1.000000" fillRule="evenodd" />
            </svg>
            <p>Назад</p>
        </div>
        </div>
    )
}

export default BackwardButton;
