import styles from "./ModalOverlay.module.scss";
import { useDispatch, useSelector } from "react-redux";
import { toggleModalOverlay } from "../../../features/managementSiteSlice";

const ModalOverlay = ({ children }) => {

    const dispatch = useDispatch();
    const { isModalOverlayOpen, theme } = useSelector((state) => state.site);

    const handleClickOverlay = (event) => {
        if (event.target === event.currentTarget) {
          dispatch(toggleModalOverlay(!isModalOverlayOpen));
        }
    }

    return isModalOverlayOpen ? (
        <div className={styles.overlay}>
            <div className={styles.overlay__background} onClick={handleClickOverlay}>
                <div className={`${styles.overlay__container} ${theme === "darkTheme" ? "" : styles.overlay__container_light}`}>
                    <div>
                        {children}
                    </div>
                </div>
            </div>


        </div>
    ) : null;
};

export default ModalOverlay;
