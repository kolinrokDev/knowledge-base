import { useSelector } from "react-redux";
import styles from "./TitleHome.module.scss";

function TitleHome({ titleTitle, titleInfo }) {

  const { theme } = useSelector((state) => state.site);
  return (
    <div className={`${styles.titleBox} container`}>
      <h1
        className={
          theme === "darkTheme"
            ? styles.titleBox__title
            : `${styles.titleBox__title} ${styles.titleBox__light}`
        }
      >
        {titleTitle}
      </h1>
      <h3
        className={
          theme === "darkTheme"
            ? styles.titleBox__slogan
            : `${styles.titleBox__slogan} ${styles.titleBox__light}`
        }
      >
        {titleInfo}
      </h3>
    </div>
  );
}

export default TitleHome;
