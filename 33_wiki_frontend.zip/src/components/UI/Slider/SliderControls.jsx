import React, { useRef } from "react";
import styles from "./sliderControls.module.scss";

const SliderControls = ({ headers, activeColumn, onColumnChange, theme, isButtonDisabled }) => {
    const headerScrollRef = useRef(null);

    const scrollHeaderToPosition = (columnIndex) => {
        const container = headerScrollRef.current;
        if (container) {
            const scrollToPosition = columnIndex * container.offsetWidth;
            container.scrollTo({
                left: scrollToPosition,
                behavior: "smooth",
            });
        }
    };

    const handleColumnChange = (direction) => {
        const newColumn = activeColumn + direction;
        if (newColumn >= 0 && newColumn < headers.length) {
            onColumnChange(newColumn);
            scrollHeaderToPosition(newColumn);
        }
    };

    return (
        <div className={`${styles.sliderControls} ${theme === "darkTheme" ? styles.theme_dark : styles.theme_light}`}>
            <button
                className={`${styles.sliderButton} ${isButtonDisabled(-1) ? styles.disabled : ""}`}
                onClick={() => handleColumnChange(-1)}
                disabled={isButtonDisabled(-1)}
            >
                <svg
                    className={theme === "darkTheme" ? styles.svg_dark : styles.svg_light}
                    width="16"
                    height="15"
                    viewBox="0 0 16 15"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path d="M0.476564 6.4414L6.10156 0.816405C6.3125 0.605468 6.59375 0.499999 6.875 0.499999C7.19141 0.499999 7.47266 0.605468 7.6836 0.816406C8.14063 1.23828 8.14063 1.97656 7.6836 2.39844L3.99219 6.125L14.75 6.125C15.3828 6.125 15.875 6.61719 15.875 7.25C15.875 7.84766 15.3828 8.375 14.75 8.375L3.99219 8.375L7.68359 12.0664C8.14063 12.4883 8.14063 13.2266 7.68359 13.6484C7.26172 14.1055 6.52344 14.1055 6.10156 13.6484L0.476564 8.02344C0.0195323 7.60156 0.0195324 6.86328 0.476564 6.4414Z" fill="white" />
                </svg>
            </button>

            <div className={styles.headerScrollable} ref={headerScrollRef}>
                {headers.map((header, index) => (
                    <div
                        key={index}
                        className={`${styles.th_item} ${index === activeColumn ? styles.active : ""}`}
                        onClick={() => {
                            if (index !== activeColumn) {
                                onColumnChange(index);
                                scrollHeaderToPosition(index);
                            }
                        }}
                    >
                        <img src={header.icon} alt={header.label} />
                        <span>{header.label}</span>
                    </div>
                ))}
            </div>

            <button
                className={`${styles.sliderButton} ${isButtonDisabled(1) ? styles.disabled : ""}`}
                onClick={() => handleColumnChange(1)}
                disabled={isButtonDisabled(1)}
            >
                <svg
                    className={theme === "darkTheme" ? styles.svg_dark : styles.svg_light}
                    width="16"
                    height="15"
                    viewBox="0 0 16 15"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path d="M15.5234 8.55859L9.89844 14.1836C9.6875 14.3945 9.40625 14.5 9.125 14.5C8.80859 14.5 8.52734 14.3945 8.31641 14.1836C7.85938 13.7617 7.85938 13.0234 8.31641 12.6016L12.0078 8.875H1.25C0.617188 8.875 0.125 8.38281 0.125 7.75C0.125 7.15234 0.617188 6.625 1.25 6.625H12.0078L8.31641 2.93359C7.85938 2.51172 7.85938 1.77344 8.31641 1.35156C8.73828 0.894531 9.47656 0.894531 9.89844 1.35156L15.5234 6.97656C15.9805 7.39844 15.9805 8.13672 15.5234 8.55859Z" fill="white" />
                </svg>
            </button>
        </div>
    );
};

export default SliderControls;
