import styles from './ArticleTitle.module.scss';
import classNames from "classnames";
import CloudDownloadButton from "../buttons/CloudDownloadButton/CloudDownloadButton.jsx";

/**
 * Заголовок статей
 * @param title текст заголовка статьи
 * @param description описание статьи (опциональный пропс)
 * @param link ссылка на документ для скачивания
 * @returns {JSX.Element}
 * @constructor
 */
const ArticleTitle = ({title, description, link}) => {
    let titleClassNames = styles.article_title;

    if (description) {
        titleClassNames = classNames(titleClassNames, styles.article_title__description);
    }

    return (
        <div className={titleClassNames}>
            <h1>{title}</h1>
            {description && <h5>{description}</h5>}
            {link && <CloudDownloadButton linkToFile={link}/>}
        </div>
    );
};

export default ArticleTitle;