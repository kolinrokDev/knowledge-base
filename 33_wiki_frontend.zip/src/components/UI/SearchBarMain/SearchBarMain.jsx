import {useEffect, useState} from "react";
import styles from "./SearchBarMain.module.scss";
import { useSelector, useDispatch } from "react-redux";
import DropDown from "../DropDown/DropDown";
import {toggleFocus} from "../../../features/managementSiteSlice";
import {useSearchRequest} from "../../../hooks/useSearchRequest.js";
import {useEscBtn} from "../../../hooks/useEscBtn.js";
import {useCloseDropDownOnClickOutside} from "../../../hooks/useCloseDropDownOnClickOutside.js";

const SearchBarMain = () => {
  const dispatch = useDispatch();

  const { theme, focus } = useSelector((state) => state.site);
  const [inputValue, setInputValue] = useState("");
  const [resultList, setResultList] = useState([]);

  // Отслеживание ввода для отправки поискового запроса на сервер
  useSearchRequest(inputValue, setResultList);
  // Снятие фокуса при нажатии кнопки Esc
  useEscBtn(() => dispatch(toggleFocus(false)));
  // Отслеживание нажатий за пределами поля ввода или выпадающего меню
  useCloseDropDownOnClickOutside(
      'div.dropdown_item',
      'input#search-bar-input',
      () => dispatch(toggleFocus(false)));

  const handleFocus = () => {
      dispatch(toggleFocus(true));
  };

  return (
    <div className={`${styles.searchBox} container`}>
      <div
        className={`${styles.searchBarMain}  ${theme === "darkTheme"
          ? styles.searchBarMain__dark
          : styles.searchBarMain__light
          }
        ${focus || theme === "darkTheme"
            ? styles.searchBarMain__dark__active
            : styles.searchBarMain__light__active
          }`}
      >
        <input
          onChange={(e) => setInputValue(e.target.value)}
          onFocus={handleFocus}
          id='search-bar-input'
          className={`${styles.input} ${focus ? styles.input__active : ""} 
          ${theme === "darkTheme" ? styles.input__dark : styles.input__light}
         `}
          type="text"
          placeholder="Поиск"
          value={inputValue}
        />
        <div
          className={`${styles.magnifyingGlass} ${focus ? styles.magnifyingGlass__hidden : ""
            }`}
        >
          <svg
            className={`${styles.magnifyingGlass__icon} ${theme === "darkTheme"
              ? styles.magnifyingGlass__icon_dark
              : styles.magnifyingGlass__icon_light
              }`}
            viewBox="0 0 31.5029 31.5031"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            xmlnsXlink="http://www.w3.org/1999/xlink"
          >
            <path
              id="Vector"
              d="M24.08 24.08L30.75 30.75M4.65 23.51C7.15 26.01 10.54 27.41 14.08 27.41C17.61 27.41 21.01 26.01 23.51 23.51C26.01 21.01 27.41 17.61 27.41 14.08C27.41 10.54 26.01 7.15 23.51 4.65C21.01 2.15 17.61 0.75 14.08 0.75C10.54 0.75 7.15 2.15 4.65 4.65C2.15 7.15 0.75 10.54 0.75 14.08C0.75 17.61 2.15 21.01 4.65 23.51Z"
              stroke="#9698A0"
              strokeOpacity="1.000000"
              strokeWidth="1.500000"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          </svg>
        </div>

        <DropDown resultList={resultList}/>
      </div>
    </div>
  );
};

export default SearchBarMain;
