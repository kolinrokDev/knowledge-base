
import styles from "./DropDownTop.module.scss";
import { useSelector } from "react-redux";

const requests = ['Запрос 1', 'Запрос 2', 'Запрос 3', 'Запрос 4', 'Запрос 5'];

const DropDownTop = () => {

  const { focus, theme } = useSelector((state) => state.site);

  return (
    <div
      className={`${styles.dropDown} ${focus ? "" : styles.dropDown_hidden
        }`}
    >
      {requests.map((item, index) => (
        <div key={index} className={`${styles.dropDown__item} 
              ${theme === "darkTheme"
            ? styles.dropDown__item__dark
            : styles.dropDown__item__light}`}>{item}</div>
      ))}
    </div>
  )
}

export default DropDownTop;
