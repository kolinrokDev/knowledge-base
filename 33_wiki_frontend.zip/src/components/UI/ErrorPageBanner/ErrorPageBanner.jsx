import { useSelector } from "react-redux";
import styles from "./ErrorPageBanner.module.scss";
import "../../../styles/App.scss";

function ErrorPageBanner() {
  const { theme } = useSelector((state) => state.site);

  return (
    <div className={`${styles.errorBox} container`}>
      <img
          src={
            theme === "darkTheme"
              ? "img/pageNotFound/404.webp"
              : "img/pageNotFound/404Light.webp"
          }
          alt="pageNotFound"
          className={`${styles.errorText__img}`}
        />
        
      <div className={styles.errorBanner}>
        <img
          src="img/pageNotFound/taksaError.webp"
          alt="Dog error"
          className={styles.errorBanner__img}
        />
      </div>
    </div>
  );
}

export default ErrorPageBanner;
