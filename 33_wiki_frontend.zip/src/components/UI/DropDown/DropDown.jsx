import styles from "./DropDown.module.scss";
import { useSelector } from "react-redux";
import {useEffect, useRef, useState} from "react";
import {useFocusMove} from "../../../hooks/useFocusMove.js";
import {Link, useNavigate} from "react-router-dom";

/**
 * Выпадающее окно с результатами поискового запроса
 * @param resultList список результатов поиска
 * @returns {JSX.Element}
 * @constructor
 */
const DropDown = ({resultList}) => {
  const MAX_LENGTH = 6;

  const { focus, theme } = useSelector((state) => state.site);
  const navigate = useNavigate();
  const [showList, setShowList] = useState(resultList);

  // Обработка списка выводимых позиций
  useEffect(() => {
    let updatedList = [...resultList];

    //Обрезать список, если результатов больше максимально допустимого значения
    if (updatedList.length > MAX_LENGTH) {
      updatedList = updatedList.slice(0, MAX_LENGTH);
    }

    setShowList(updatedList);
    }, [resultList]);

  //Перемещение фокуса
  useFocusMove(showList.length);

  /**
   * Перехват нажатий клавиш
   * @param e эвент
   * @param link ссылка для перехода
   */
  const pressKey = (e, link) => {
    if (e.key === "Enter") {
      navigate(link);
    }
  }

  return (
    <div
      className={`${styles.dropDown} ${focus ? "" : styles.dropDown_hidden
        }`}
    >
      {showList.map((item, index) => (
        <div key={index} id={`dropdown_item_${index}`} tabIndex={0}
             onKeyDown={(e) => pressKey(e, item.link)}
             className={`dropdown_item ${styles.dropDown__item} 
                ${theme === "darkTheme"
                  ? styles.dropDown__item__dark
                  : styles.dropDown__item__light}`}>
          <Link to={item.link}>{item.title}</Link>
        </div>
      ))}
    </div>
  )
}

export default DropDown;
