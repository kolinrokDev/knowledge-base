import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import styles from "./BackgroundTextPages.module.scss";

const BackgroundTextPages = () => {
  const { theme } = useSelector((state) => state.site);
      
  const colorArrayOne = [
    "rgba(61, 196, 235, 1)",
    "rgba(255, 69, 187, 1)",
    "rgba(106, 239, 157, 1)",
    "rgba(61, 196, 235, 1)",
  ];

  const colorArrayTwo = [
    "rgba(255, 149, 29, 1)",
    "rgba(61, 122, 255, 1)",
    "rgba(239, 106, 108, 1)",
    "rgba(45, 211, 30, 1)",
  ];

  const circles = ["one", "two", "three", "four"];

  // Рандомный выбор цветовой схемы при монтировании
  const [activeColors, setActiveColors] = useState([]);

  useEffect(() => {
    setActiveColors(Math.random() > 0.5 ? colorArrayOne : colorArrayTwo);
  }, []);

  return (
    <>
            <div
              className={
              theme === "darkTheme"
              ? `${styles.absolute} ${styles.absolute__dark}`
              : `${styles.absolute} ${styles.absolute__light}`
              }
            >
            
              {/* Круги, упорядоченные по цвету и позициям */}
                <div className={
                  theme === "darkTheme"
                  ? `${styles.background} ${styles.background__dark}`
                  : `${styles.background} ${styles.background__light}`
                }>
                {activeColors.map((color, index) => (
                <div
                  key={index}
                  className={`${styles.circle} ${styles[`circle__${index + 1}`]}`}
                  style={{ backgroundColor: color }}
                ></div>
              ))}
            </div>
                
            {/* Блоки кода, расположенные в определенных местах */}
            <div
              className={`${styles.text} ${
              theme === "darkTheme" ? "" : styles.text_light
              }`}
            >
            <pre className={`${styles.text__codeOne}`}>
              {`73 class="search-box hidden-xs hidden-sin pull-left ml-10" 
74 <?php get_search_form(); ?>
75 </div>
76 class="submit-btn hidden-xs hidden-sm pull-left ol-10"
77 <a href="<?php echo get_page_link($xpanell'submit-link'1)"
78 </div>
79 <div class="user-info pull-right mr-10">`}
            </pre>
          </div>
                
          <div
            className={`${styles.text} ${
            theme === "darkTheme" ? "" : styles.text_light
            }`}
          >
          <pre className={`${styles.text__codeTwo}`}>
            {`51  I(document, 'script', 'facebook-jssdk'));</script>
52  div id="page" class="site">
53  class="skip-link screen-reader-text" href="#content"><?php esc_html_el "skip to content",
54  <header id="masthead" class="site-header" role="banner">
55  <div class="site-branding">
56  <div class="navBtn pull-left">
57  <?php if(is_home() & $xpanel['homepage-style']
58  =
59  u"><i class="fa fa-bars
60  fa-3x"></ ></
61  href="#"
62  id="openMenu">
63  <?php else ?>
64  <a href="#" id="openMenu2"><i class="fa fa-bars fa-3x"></ ></
65  <?php ?>
66  </div>`}
          </pre>
        </div>
                
        <div
          className={`${styles.text} ${
          theme === "darkTheme" ? "" : styles.text_light
          }`}
        >
          <pre className={`${styles.text__codeThree}`}>
            {`67  <div class=" logo pull-left">
68  href="<?php echo esc_url( home_url()
69  ) ?>">
70  src="<?php echo $xpanel["logo"]['url'] ?>">
71  </a>
72  </div>`}
          </pre>
        </div>
                
        {/* Окружности */}
        {circles.map((circle, index) => (
          <div key={index} className={`${styles.around} ${styles[`around__${circle}`]}`}>
            <div className={`${styles.around__first} ${theme === "darkTheme" ? "" : styles.around_light}`}>
              <div className={`${styles.around__second} ${theme === "darkTheme" ? "" : styles.around__second_light}`}>
                <div className={`${styles.around__third} ${theme === "darkTheme" ? "" : styles.around_light}`}></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default BackgroundTextPages;
