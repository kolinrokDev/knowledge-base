/**
 * Рамка с указателем
 * @returns {JSX.Element}
 * @constructor
 */
const ThinkFrameIcon = () => {
    return (
        <svg viewBox="0 0 211 180" fill="none"
             xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
            <path id="Vector"
                  d="M18.34 2.5C14.14 2.5 10.11 4.15 7.14 7.1C4.16 10.05 2.5 14.04 2.5 18.21L2.5 123C2.5 127.17 4.16 131.17 7.14 134.12C10.11 137.07 14.14 138.72 18.34 138.72L27 138.72L27 177.5L70.63 138.72L192.65 138.72C196.85 138.72 200.88 137.07 203.85 134.12C206.83 131.17 208.5 127.17 208.5 123L208.5 18.21C208.5 14.04 206.83 10.05 203.85 7.1C200.88 4.15 196.85 2.5 192.65 2.5L18.34 2.5Z"
                  stroke="#FFFFFF" strokeOpacity="1.000000" strokeWidth="5.000000" strokeLinejoin="round"/>
        </svg>
    );
};

export default ThinkFrameIcon;