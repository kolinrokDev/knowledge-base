const CheckIcon = ({ color = "black" }) => {
    return (
        <svg
            className="checkIcon"
            width="27"
            height="23"
            viewBox="0 0 27 23"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                d="M25.334 1L8.53398 21L1.33398 13.5"
                stroke={color}
                strokeWidth="1.375"
                strokeMiterlimit="10"
                strokeLinecap="square"
            />
        </svg>
    );
};

export default CheckIcon;