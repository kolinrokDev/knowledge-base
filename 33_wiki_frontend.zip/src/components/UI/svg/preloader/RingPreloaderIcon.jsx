/**
 * Иконка кольца для прелоадера
 * @returns {JSX.Element}
 * @constructor
 */
const CirclePreloaderIconStyle = () => {
    return (
        <svg width="41.269043" height="41.269287" viewBox="0 0 41.269 41.2693" fill="none"
             xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
            <defs>
                <radialGradient gradientTransform="rotate(90) scale(20.6346 20.6346)" cx="0.000000" cy="0.000000"
                                r="1.000000" id="paint_angular_443_1560_0" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#02F6FE"/>
                    <stop offset="1.000000" stopColor="#737373" stopOpacity="0.000000"/>
                </radialGradient>
            </defs>
            <path id="Ellipse 12"
                  d="M20.63 0C9.24 0 0 9.24 0 20.63C0 32.02 9.24 41.26 20.63 41.26C32.02 41.26 41.26 32.02 41.26 20.63C41.26 9.24 32.02 0 20.63 0ZM9.88 29.65C7.83 27.21 6.59 24.06 6.59 20.63C6.6 17.44 7.67 14.24 9.88 11.61C11.93 9.17 14.81 7.4 18.19 6.81C21.33 6.26 24.67 6.76 27.65 8.48C30.41 10.07 32.64 12.6 33.81 15.83C34.91 18.83 34.99 22.2 33.81 25.43C32.73 28.42 30.62 31.07 27.64 32.78C24.89 34.38 21.57 35.05 18.19 34.45C15.05 33.9 12.08 32.28 9.88 29.65Z"
                  fill="url(#paint_angular_443_1560_0)" fillOpacity="1.000000" fillRule="evenodd"/>
        </svg>
    );
};

export default CirclePreloaderIconStyle;