/**
 * Точка (для анимации прелоадера)
 * @returns {JSX.Element}
 * @constructor
 */
const DotIcon = () => {
    return (
        <svg width="15.000000" height="15.000000" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"
             xmlnsXlink="http://www.w3.org/1999/xlink">
            <defs>
                <linearGradient x1="15.000000" y1="-0.000002" x2="0.000003" y2="14.999995" id="paint_linear_439_1375_0"
                                gradientUnits="userSpaceOnUse">
                    <stop stopColor="#02F6FE"/>
                    <stop offset="1.000000" stopColor="#276B67"/>
                </linearGradient>
            </defs>
            <circle id="Ellipse 11" cx="7.500000" cy="7.500000" r="7.500000" fill="url(#paint_linear_439_1375_0)"
                    fillOpacity="1.000000"/>
        </svg>
    );
};

export default DotIcon;