/**
 * Иконка-крестик
 * @returns {JSX.Element}
 * @constructor
 */
const CrossSvg = () => {
    return (
        <svg width="19.505859" height="19.505859" viewBox="0 0 19.5059 19.5059" fill="none"
             xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
            <path id="Vector" d="M18.75 0.75L0.75 18.75M0.75 0.75L18.75 18.75" stroke="#000000"
                  strokeOpacity="1.000000" strokeWidth="1.500000" strokeLinejoin="round" strokeLinecap="round"/>
        </svg>
    );
};

export default CrossSvg;