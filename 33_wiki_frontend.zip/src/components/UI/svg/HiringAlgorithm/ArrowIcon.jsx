/**
 * Иконка стрелки
 * @returns {JSX.Element}
 * @constructor
 */
const ArrowIcon = () => {
    return (
        <svg width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2.95269 2.47211L16.152 2.47211M16.152 2.47211L16.152 15.6714M16.152 2.47211L1.86621 16.5332"
                  stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    );
};

export default ArrowIcon;