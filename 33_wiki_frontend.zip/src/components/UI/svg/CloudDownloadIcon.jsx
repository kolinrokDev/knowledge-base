const CloudDownloadIcon = () => {
    return (
        <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g filter="url(#filter0_bi_1112_4688)">
            <circle cx="24" cy="24" r="24" fill="white" fillOpacity="0.1" />
            <circle cx="24" cy="24" r="23.5" stroke="#02C5FE" strokeOpacity="0.5" />
        </g>
        <path d="M23.5862 25.407V38.0691M23.5862 38.0691L28.4577 33.1449M23.5862 38.0691L18.7148 33.1449M34.721 31.8886C36.8004 31.0656 38.8966 29.1902 38.8966 25.407C38.8966 19.7794 34.2575 18.3725 31.9373 18.3725C31.9373 15.5587 31.9373 9.93115 23.5862 9.93115C15.2351 9.93115 15.2351 15.5587 15.2351 18.3725C12.9149 18.3725 8.27588 19.7794 8.27588 25.407C8.27588 29.1902 10.372 31.0656 12.4514 31.8886" stroke="#02C5FE" strokeOpacity="0.5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        <defs>
            <filter id="filter0_bi_1112_4688" x="-5" y="-5" width="58" height="58" filterUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feGaussianBlur in="BackgroundImageFix" stdDeviation="2.5" />
                <feComposite in2="SourceAlpha" operator="in" result="effect1_backgroundBlur_1112_4688" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect1_backgroundBlur_1112_4688" result="shape" />
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                <feOffset />
                <feGaussianBlur stdDeviation="5.2" />
                <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
                <feColorMatrix type="matrix" values="0 0 0 0 0.00784314 0 0 0 0 0.772549 0 0 0 0 0.996078 0 0 0 1 0" />
                <feBlend mode="normal" in2="shape" result="effect2_innerShadow_1112_4688" />
            </filter>
        </defs>
    </svg>
    )
};

export default CloudDownloadIcon;