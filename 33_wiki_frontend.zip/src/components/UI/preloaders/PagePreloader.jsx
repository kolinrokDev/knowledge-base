import SimplePreloader from "./SimplePreloader.jsx";
import DotsPreloader from "./DotsPreloader.jsx";
import RingPreloader from "./RingPreloader.jsx";
import styles from "./Preloaders.module.scss";
import BackgroundContainer from "../BackgroundContainer/BackgroundContainer.jsx";

/**
 * Прелоадер страницы
 * @param name имя загрузчика
 * @returns {JSX.Element}
 * @constructor
 */
const PagePreloader = ({name = 'dots'}) => {
    /**
     * Список прелоадеров
     * (Как разрастётся вынести в отдельный компонент)
     * @type {{simple: JSX.Element}}
     */
    const preloaders = {
        simple: <SimplePreloader/>,
        dots: <DotsPreloader/>,
        ring: <RingPreloader/>,
    };

    return (
        <div className={styles.preloader_page}>
            <BackgroundContainer />
            {preloaders[name]}
        </div>
    );
};

export default PagePreloader;