import style from './Preloaders.module.scss';

/**
 * Прелоадер-заглушка на время разработки
 * @constructor
 */
const SimplePreloader = () => {
    return <p className={style.preloader_simple}>Loading...</p>;
};

export default SimplePreloader;