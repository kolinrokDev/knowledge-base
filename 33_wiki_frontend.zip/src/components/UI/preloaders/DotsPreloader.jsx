import DotIcon from "../svg/preloader/DotIcon";
import styles from "./Preloaders.module.scss";

/**
 * Анимированный прелоаден "скачущие точки"
 * @returns {JSX.Element}
 * @constructor
 */
const DotsPreloader = () => {
    return (
        <div className={styles.preloader_dots}>
            <DotIcon/>
            <DotIcon/>
            <DotIcon/>
        </div>
    );
};

export default DotsPreloader;