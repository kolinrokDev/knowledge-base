import RingPreloaderIcon from "../svg/preloader/RingPreloaderIcon.jsx";
import styles from "./Preloaders.module.scss";

/**
 * Прелоадер в виде крутящего кольца
 * @returns {JSX.Element}
 * @constructor
 */
const RingPreloader = () => {
    return (
        <div className={styles.preloader_ring}>
            <RingPreloaderIcon/>
        </div>
    );
};

export default RingPreloader;