import styles from './SelectedColorButtonNavigation.module.scss';
import ArrowIcon from "../../svg/HiringAlgorithm/ArrowIcon.jsx";
import {useEffect, useState} from "react";
import classNames from "classnames";
import {useSelector} from "react-redux";
import DachshundIcon from "./svg/DachshundIcon.jsx";
import BtnNavFrame from "./svg/BtnNavFrame.jsx";

/**
 * Кнопка навигации с выбором цвета
 * @param title {string} имя подкатегории (текст на кнопке)
 * @param color {string} цвет кнопки
 * @returns {JSX.Element}
 * @constructor
 */
const SelectedColorButtonNavigation = ({title, color = 'blue'}) => {
    const theme = useSelector(state => state.site.theme);
    const [siteTheme, setSiteTheme] = useState(theme === 'darkTheme' ? 'dark' : 'light');

    //Классы контейнера кнопки
    const containerClassNames = classNames(styles.container,
        styles[`container__${color}`],
        styles[`container__${siteTheme}`],
        styles[`container__${color}__${siteTheme}`]);

    //Классы изображения кнопки
    const boxClassNames = classNames(styles.box,
        styles[`box__${color}`],
        styles[`box__${siteTheme}`],
        styles[`box__${color}__${siteTheme}`]);

    //Переключатель светлой/тёмной темы
    useEffect(() => {
        setSiteTheme(theme === 'darkTheme' ? 'dark' : 'light');
    }, [theme]);

    return (
        <div tabIndex={title ? 0 : -1} className={containerClassNames}>
            <div className={boxClassNames}>
                <p>{title}</p>
                {title && <ArrowIcon/>}
            </div>
            <BtnNavFrame/>
            {!title && <DachshundIcon/>}
        </div>
    );
};

export default SelectedColorButtonNavigation;