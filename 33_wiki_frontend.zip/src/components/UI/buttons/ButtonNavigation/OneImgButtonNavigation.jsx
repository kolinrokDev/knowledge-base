import OneImgSvg from "./svg/OneImgSvg.jsx";

/** @deprecated */
const OneImgButtonNavigation = ({title, color}) => {

    return (
        <div>
            <OneImgSvg color={color}/>
        </div>
    );
};

export default OneImgButtonNavigation;