/** @deprecated */
const LinearGradientDefaultInactive = () => {
    return (
        <linearGradient x1="71.182739" y1="30.999969" x2="247.773651" y2="120.500031" id="paint-default-inactive"
                        gradientUnits="userSpaceOnUse">
            <stop stopColor="#046F8E"/>
            <stop offset="1.000000" stopColor="#000000"/>
        </linearGradient>
    );
};

export default LinearGradientDefaultInactive;