
/** @deprecated */
const FilterDefaultInactive = () => {
    return (
        <filter id="filter-default-inactive" x="0.000000" y="0.000000" width="349.031250" height="121.000000"
                filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood floodOpacity="0" result="BackgroundImageFix"/>
            <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                           result="hardAlpha"/>
            <feOffset dx="0" dy="0"/>
            <feGaussianBlur stdDeviation="10"/>
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0.44314 0 0 0 0 0.57255 0 0 0 1 0"/>
            <feBlend mode="normal" in2="shape" result="effect_innerShadow_1"/>
        </filter>
    );
};

export default FilterDefaultInactive;