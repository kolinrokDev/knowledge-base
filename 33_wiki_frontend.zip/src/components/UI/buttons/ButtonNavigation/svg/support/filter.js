import FilterDefaultInactive from "../default/FilterDefaultInactive.jsx";

/** @deprecated */
export const inactiveFilters = {
    default: <FilterDefaultInactive/>,
    orange: <></>,
    green: <></>,
    violet: <></>,
};