import LinearGradientDefaultInactive from "../default/LinearGradientDefaultInactive.jsx";

/** @deprecated */
export const inactiveGradient = {
    default: <LinearGradientDefaultInactive/>,
    orange: <></>,
    green: <></>,
    violet: <></>,
};