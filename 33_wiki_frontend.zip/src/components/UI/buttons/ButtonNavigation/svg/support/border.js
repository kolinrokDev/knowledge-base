/** @deprecated */
export const border = {
    default: "#02C5FE",
    orange: "",
    green: "",
    violet: "",
};