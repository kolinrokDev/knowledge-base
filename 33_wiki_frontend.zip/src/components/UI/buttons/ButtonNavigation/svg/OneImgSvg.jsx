import {useEffect, useState} from "react";
import {inactiveFilters} from "./support/filter.js";
import {inactiveGradient} from "./support/gradient.js";
import {border} from "./support/border.js";
import {useSelector} from "react-redux";

/**
 * Иконка кнопки навигации, перестраиваемая в зависимости от цветового стиля
 * @param color
 * @returns {JSX.Element}
 * @constructor
 * @deprecated
 */
const OneImgSvg = ({color}) => {
    const [activeColorThem, setActiveColorThem] = useState('default');
    const [hoverFlag, setHoverFlag] = useState('inactive');
    const [isLight, setIsLight] = useState(false);

    const {theme} = useSelector(state => state.site);

    useEffect(() => {
        switch (color) {
            case 'orange':
                setActiveColorThem('orange');
                break;
            case 'green':
                setActiveColorThem('green');
                break;
            case 'violet':
                setActiveColorThem('violet');
                break;
            default:
                setActiveColorThem('default');
        }
    }, []);

    useEffect(() => {
        setIsLight(theme === 'lightTheme');
    }, [theme]);

    return (
        <svg width="349.031250" height="121.000000" viewBox="0 0 349.031 121" fill="none"
             xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
            <defs>
                {inactiveFilters[activeColorThem]}
                {inactiveGradient[activeColorThem]}
            </defs>
            <g filter={`url(#filter-${activeColorThem}-${hoverFlag})`}>
                <path id="body"
                      d="M20.22 0.5C15.76 0.5 11.84 3.45 10.61 7.73L0.76 41.93C-0.36 45.82 2.56 49.7 6.61 49.7L6.61 49.7C9.96 49.7 12.69 52.42 12.69 55.78L12.69 110.5C12.69 116.02 17.16 120.5 22.69 120.5L338.53 120.5C344.05 120.5 348.53 116.02 348.53 110.5L348.53 89.62C348.53 85.96 345.56 83 341.9 83L341.9 83C338.24 83 335.27 80.03 335.27 76.37L335.27 33.98C335.27 31.42 336.25 28.96 338.01 27.1L345.79 18.89C347.55 17.03 348.53 14.57 348.53 12.01L348.53 10.5C348.53 4.97 344.05 0.5 338.53 0.5L20.22 0.5Z"
                      fill={`url(#paint-${activeColorThem}-${hoverFlag})`} fillOpacity="1.000000" fillRule="nonzero"/>
            </g>
            <path id="body"
                  d="M0.76 41.93C-0.36 45.82 2.56 49.7 6.61 49.7C9.96 49.7 12.69 52.42 12.69 55.78L12.69 110.5C12.69 116.02 17.16 120.5 22.69 120.5L338.53 120.5C344.05 120.5 348.53 116.02 348.53 110.5L348.53 89.62C348.53 85.96 345.56 83 341.9 83C338.24 83 335.27 80.03 335.27 76.37L335.27 33.98C335.27 31.42 336.25 28.96 338.01 27.1L345.79 18.89C347.55 17.03 348.53 14.57 348.53 12.01L348.53 10.5C348.53 4.97 344.05 0.5 338.53 0.5L20.22 0.5C15.76 0.5 11.84 3.45 10.61 7.73L0.76 41.93Z"
                  stroke={!isLight && border[activeColorThem]} strokeOpacity="1.000000" strokeWidth="1.000000"/>
        </svg>
    );
};

export default OneImgSvg;