import { useSelector } from "react-redux";
import styles from "./ButtonNavigation.module.scss";

/** @deprecated */
const ButtonNavigation = ({ nameLink }) => {
  const { theme } = useSelector((state) => state.site);

  return (
    <div
      className={`${styles.button} ${
        theme === "darkTheme" ? styles.button__dark : styles.button__light
      }`}
    >
      <div className={styles.button__title}>{nameLink}</div>

      <div
        className={`${nameLink ? styles.button__row : styles.dachshund} ${
          theme === "darkTheme" && nameLink
            ? styles.button__row_dark
            : styles.button__row_light
        }`}
      ></div>
    </div>
  );
};

export default ButtonNavigation;
