import { useState, useEffect } from "react";
import CloudDownloadIcon from "../../svg/CloudDownloadIcon";
import styles from "./CloudDownloadButton.module.scss";

/**
 * Кнопка открытия/скачивания документа в виде облака
 * @param linkToFile ссылка на файл-документ
 * @returns {JSX.Element}
 * @constructor
 */

const CloudDownloadButton = ({linkToFile}) => {
    const [windowWidth, setWindowWidth] = useState(window.innerWidth);

    useEffect(() => {
        const windowSizeHandler = () => {
            setWindowWidth(window.innerWidth);
        };
        window.addEventListener("resize", windowSizeHandler);
    
        return () => {
          window.removeEventListener("resize", windowSizeHandler);
        };
    }, []); 

    return (
        <a 
            href={linkToFile}
            target='_blank'  
            download={windowWidth < 768 ? true : false}
            className={`${styles.download__button}`}
        >
            <CloudDownloadIcon />
        </a>
    );
};

export default CloudDownloadButton;