import CrossSvg from "../svg/buttons/CrossSvg";

/**
 * Кнопка закрытия в виде крестика
 * @param action событие по нажатию
 * @param className имя класса для кнопки
 * @returns {JSX.Element}
 * @constructor
 */
const CloseButton = ({action, className = ""}) => {
    return (
        <button onClick={action} className={className}>
            <CrossSvg/>
        </button>
    );
};

export default CloseButton;