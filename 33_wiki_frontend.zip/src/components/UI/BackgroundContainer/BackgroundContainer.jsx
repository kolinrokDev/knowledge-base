import styles from "./BackgroundContainer.module.scss";
import BackgroundGrain from "../BackgroundGrain/BackgroungGrain";
import {useSelector} from "react-redux";
import {useEffect, useState} from "react";
import classNames from "classnames";

/**
 *
 * @param colorTheme цветовое обозначение темы заднего фона (по умолчанию blue)
 * @returns {JSX.Element}
 * @constructor
 */
export default function BackgroundContainer({colorTheme = 'blue'}) {
    const {theme} = useSelector((state) => state.site);

    //Цветовая тема кругов заднего фона
    const bgShapeColorStyle = `bgShape__${theme.replace('Theme', '')}_${colorTheme}`;

    //Набор стилей для фигур заднего фона
    const [bgShapeClasses, setBgShapeClasses] =
        useState(classNames(styles.bgShape, styles[bgShapeColorStyle]));

    // Флаг для отображения BackgroundGrain
    const [showBackgroundGrain, setShowBackgroundGrain] = useState(theme === "darkTheme");

    //Смена темы
    useEffect(() => {
        const bgShapeColorStyle = `bgShape__${theme.replace('Theme', '')}_${colorTheme}`;
        let classes = classNames(styles.bgShape, styles[bgShapeColorStyle]);

        if (theme === "lightTheme") {
            classes = classNames(classes, styles.bgShape__light);
        }

        setBgShapeClasses(classes);
        setShowBackgroundGrain(theme === "darkTheme");
    }, [theme]);

    return (
        <div className={`${theme === "darkTheme"
            ? `${styles.container} ${styles.container__dark}`
            : `${styles.container} ${styles.container__ligth}`
        } container`}>
            {showBackgroundGrain && <BackgroundGrain />}
            <div className={classNames(styles.squares_box, 'container')}>
                {[1, 2, 3].map(i => <div key={i} className={bgShapeClasses}></div>)}
            </div>
        </div>
    );
}
