import TitleHome from "../UI/TitleHome/TitleHome.jsx";
import Navigation from "../Navigation/Navigation.jsx";
import WithHeaderAndFooter from "../../supports/WithHeaderAndFooter.jsx";
import BackgroundContainer from "../UI/BackgroundContainer/BackgroundContainer.jsx";

/**
 * Основной контент страниц подкатегорий
 * @constructor
 */
const PageTemplateMain = ({category}) => {
    return (
        <WithHeaderAndFooter background={<BackgroundContainer colorTheme={category.pageStyle}/>}>
            <TitleHome titleTitle={category.name} titleInfo={category.description}/>
            <Navigation customNavigationData={category.subcategory} colorTheme={category.pageStyle}/>
        </WithHeaderAndFooter>
    );
};

export default PageTemplateMain;