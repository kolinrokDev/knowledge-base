import "./styles/App.scss";
import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import PageNotFound from "./pages/PageNotFound";
import PageTemplate from "./pages/PageTemplate";
import FaqPage from "./pages/FaqPage.jsx";
import ProjectsReviewPage from "./pages/ProjectsReviewPage";
import GitlabPage from "./pages/GitlabPage";
import DictionaryPage from "./pages/DictionaryPage";
import HiringAlgorithmPage from "./pages/HiringAlgorithmPage.jsx";
import ModalOverlay from "./components/UI/ModalOverlay/ModalOverlay";
import ModalWindowFeedback from "./components/ModalWindowFeedback/ModalWindowFeedback";
import ServerOverloadPage from "./pages/ServerOverloadPage.jsx";
import AccessPage from "./pages/AccessPage";
import SchoolEntrancePage from "./pages/SchoolEntrancePage";
import KaitenRegistrationPage from "./pages/KaitenRegistrationPage";
import InterviewPage from "./pages/InterviewPage.jsx";
import TeamRegistrationPage from "./pages/TeamRegistrationPage.jsx";
import TestPage from "./pages/TestPage.jsx";
import Footer from "./components/Footer/Footer.jsx";

function App() {
  return (
    <>
      <ModalOverlay>
        <ModalWindowFeedback />
      </ModalOverlay>

      {/* Основной контейнер */}
      <div className="page-container">
        {/* Основной контент */}
        <div className="page-content">
          <Routes>
            {/* Главная страница */}
            <Route path="/" element={<Home />} />
            {/* Страница шаблон */}
            <Route path="/category/:id" element={<PageTemplate />} />
            {/* Текстовые страницы */}
            <Route path="/gitlab" element={<GitlabPage />} />
            <Route path="/access" element={<AccessPage />} />
            <Route path="/interview" element={<InterviewPage />} />
            <Route path="/Review" element={<ProjectsReviewPage />} />
            <Route path="/dictionary" element={<DictionaryPage />} />
            <Route path="/FAQ" element={<FaqPage />} />
            <Route path="/schoolEntrance" element={<SchoolEntrancePage />} />
            <Route
              path="/kaitenRegistration"
              element={<KaitenRegistrationPage />}
            />
            <Route path="/HiringAlgorithm" element={<HiringAlgorithmPage />} />
            <Route path="/team-registration" element={<TeamRegistrationPage />} />
            {/* TODO убрать перед продом */}
            {/* Страница тестирования компонентов */}
            <Route path="/test" element={<TestPage />}/>
            {/* Страница ошибок */}
            <Route path="*" element={<PageNotFound />} />
            <Route path="/servererror" element={<ServerOverloadPage />} />
          </Routes>
          </div>
        {/* Футер всегда внизу */}
        <Footer />
      </div>
    </>
  );
}

export default App;
