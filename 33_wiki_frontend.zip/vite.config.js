import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";

export default defineConfig(() => {
  const apiUrl = process.env.VITE_WIKI_APP_API__BASE_URL;

  return {
    plugins: [react()],
    css: {
      preprocessorOptions: {
        scss: {
          api: "modern-compiler",
        },
      },
    },
    server: {
      proxy: {
        "/api": {
          target: apiUrl,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/api/, ""),
        },
      },
    },
    build: {
      rollupOptions: {
        output: {
          manualChunks(id) {
            // Разделяем зависимости из node_modules в отдельный чанк
            if (id.includes("node_modules")) {
              return "vendor";
            }
            // Например, если есть какие-то большие компоненты, вы можете их также разделить
            if (id.includes("src/components")) {
              return "components"; // Разделить компоненты в отдельный чанк
            }
          },
        },
      },
      sourcemap: false,
      chunkSizeWarningLimit: 1000, // Увеличить лимит предупреждения до 1000 кБ
    },
  };
});
