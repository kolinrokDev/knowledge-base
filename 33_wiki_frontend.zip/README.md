# Проект База Знаний школы Guild of developers

Сайт-библиотека с полезными материалами, для стажеров guild-of-developers

### Стэк проекта

- React+JavaScript
- Vite
- React Router
- Redux Toolkit
- Axios
- CSS/SCSS

### Системные требования

На вашу локальную машину необходимо установить [Node.js](https://nodejs.org/en/download/prebuilt-installer/current)

### Для запуска проекта локально:

1.  Клонируйте репозиторий: `git clone https://github.com/your-project-name`
2.  Перейдите в папку с проектом: `cd your-project-name`
3.  Установите зависимости: `npm install` или `yarn install`
4.  Создайте файл .env.development и прописать туда
   `VITE_WIKI_APP_API__BASE_URL=https://wiki-test.god-it.ru`
5.  Запуск проекта: `npm run dev`
6.  Откройте в браузере `http://localhost:5173`


При разработке:
- При написании слайсов запросов к бэкенду, необходимо импортировать функцию `getApiUrl` из `src\supports\apiUtils.js` и использовать ее для получения url бэкенда.


---
- Разработчики проекта: Эрина Ксения, Александр Емельянов, Никита Матвеев, Валерий Панов, Федорова Гульнара, Андрей Сенин.
- Заказчик проекта: [guild-of-developers](https://guild-of-developers.ru/), Журавлева Олеся

